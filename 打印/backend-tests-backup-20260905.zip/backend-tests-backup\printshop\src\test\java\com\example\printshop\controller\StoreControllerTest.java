package com.example.printshop.controller;

import com.example.printshop.common.ApiException;
import com.example.printshop.entity.Store;
import com.example.printshop.security.AuthContext;
import com.example.printshop.security.AuthPrincipal;
import com.example.printshop.service.StoreService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class StoreControllerTest {
    private StoreService storeService;
    private StoreController controller;

    @BeforeEach
    void setUp() {
        storeService = mock(StoreService.class);
        controller = new StoreController();
        ReflectionTestUtils.setField(controller, "service", storeService);
    }

    @AfterEach
    void tearDown() {
        AuthContext.clear();
    }

    @Test
    void activeStoreListDoesNotExposeDeviceMetadata() {
        Store store = store(1);
        store.setDeviceCode("printer-device-001");
        store.setCreateTime(new Date());
        store.setUpdateTime(new Date());
        when(storeService.getByStatus(1)).thenReturn(List.of(store));

        List<Store> result = controller.getActive();

        assertEquals(1, result.size());
        assertEquals(1, result.get(0).getId());
        assertEquals("主店", result.get(0).getName());
        assertNull(result.get(0).getDeviceCode());
        assertNull(result.get(0).getCreateTime());
        assertNull(result.get(0).getUpdateTime());
    }

    @Test
    void userCannotReadFullStoreList() {
        AuthContext.set(userPrincipal(7));

        ApiException exception = assertThrows(ApiException.class, () -> controller.getAll());

        assertEquals(403, exception.getStatus());
        verify(storeService, never()).getAll();
    }

    @Test
    void adminCanReadFullStoreList() {
        AuthContext.set(adminPrincipal(1));
        List<Store> stores = List.of(store(1));
        when(storeService.getAll()).thenReturn(stores);

        List<Store> result = controller.getAll();

        assertEquals(stores, result);
    }

    @Test
    void userCannotReadStoreDetail() {
        AuthContext.set(userPrincipal(7));

        ApiException exception = assertThrows(ApiException.class, () -> controller.getById(1));

        assertEquals(403, exception.getStatus());
        verify(storeService, never()).getById(1);
    }

    private Store store(Integer id) {
        Store store = new Store();
        store.setId(id);
        store.setName("主店");
        store.setShortName("主店");
        store.setAddress("校内");
        store.setPhone("4007781811");
        store.setHours("09:00-21:00");
        store.setServices("打印");
        store.setStatus(1);
        store.setSortOrder(1);
        return store;
    }

    private AuthPrincipal userPrincipal(Integer id) {
        AuthPrincipal principal = new AuthPrincipal();
        principal.setId(id);
        principal.setType("user");
        principal.setSubject("user:" + id);
        return principal;
    }

    private AuthPrincipal adminPrincipal(Integer id) {
        AuthPrincipal principal = new AuthPrincipal();
        principal.setId(id);
        principal.setType("admin");
        principal.setRole("admin");
        principal.setSubject("admin:" + id);
        return principal;
    }
}
