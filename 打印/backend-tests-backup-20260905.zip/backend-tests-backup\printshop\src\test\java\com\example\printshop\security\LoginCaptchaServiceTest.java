package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.security.SecureRandom;
import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class LoginCaptchaServiceTest {
    private StringRedisTemplate redisTemplate;
    private ValueOperations<String, String> valueOperations;
    private LoginCaptchaService service;

    @BeforeEach
    @SuppressWarnings("unchecked")
    void setUp() {
        redisTemplate = mock(StringRedisTemplate.class);
        valueOperations = mock(ValueOperations.class);
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        service = new LoginCaptchaService(redisTemplate, 120, new SecureRandom());
    }

    @Test
    void createsImageAndStoresAnswerWithTtl() {
        LoginCaptchaService.Captcha captcha = service.create();
        ArgumentCaptor<String> key = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> answer = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Duration> ttl = ArgumentCaptor.forClass(Duration.class);

        verify(valueOperations).set(key.capture(), answer.capture(), ttl.capture());

        assertTrue(key.getValue().endsWith(captcha.captchaId()));
        assertEquals(4, answer.getValue().length());
        assertEquals(Duration.ofSeconds(120), ttl.getValue());
        assertTrue(captcha.image().startsWith("data:image/png;base64,"));
        assertEquals(120, captcha.expiresIn());
    }

    @Test
    void verifiesCaseInsensitivelyAndConsumesCaptcha() {
        when(valueOperations.getAndDelete("printshop:login:captcha:test-id")).thenReturn("A2BC");

        service.verify("test-id", "a2bc");

        verify(valueOperations).getAndDelete("printshop:login:captcha:test-id");
    }

    @Test
    void rejectsMissingExpiredOrIncorrectCaptcha() {
        ApiException missing = assertThrows(ApiException.class, () -> service.verify("", ""));
        assertEquals(400, missing.getStatus());

        when(valueOperations.getAndDelete("printshop:login:captcha:expired")).thenReturn(null);
        ApiException expired = assertThrows(ApiException.class, () -> service.verify("expired", "ABCD"));
        assertEquals(400, expired.getStatus());

        when(valueOperations.getAndDelete("printshop:login:captcha:wrong")).thenReturn("WXYZ");
        ApiException wrong = assertThrows(ApiException.class, () -> service.verify("wrong", "ABCD"));
        assertEquals(400, wrong.getStatus());
    }

    @Test
    void reportsRedisOutageAsServiceUnavailable() {
        when(valueOperations.getAndDelete(any())).thenThrow(new RedisConnectionFailureException("down"));

        ApiException exception = assertThrows(ApiException.class, () -> service.verify("id", "ABCD"));

        assertEquals(503, exception.getStatus());
        assertNotNull(exception.getMessage());
    }
}
