package com.example.printshop.gateway.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GatewaySecurityFilterTest {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final String JWT_SECRET = "gateway-test-secret-with-more-than-32-characters";

    @Test
    void allowsRequestsWithinConfiguredWindow() {
        GatewaySecurityProperties properties = properties(2, 60);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            downstreamCalls.incrementAndGet();
            exchange.getResponse().setStatusCode(HttpStatus.OK);
            return Mono.empty();
        };

        filter.filter(exchange("/api/order/1"), chain).block();
        filter.filter(exchange("/api/order/2"), chain).block();

        assertEquals(2, downstreamCalls.get());
    }

    @Test
    void rejectsRequestsBeyondConfiguredWindow() {
        GatewaySecurityProperties properties = properties(1, 60);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            downstreamCalls.incrementAndGet();
            return Mono.empty();
        };
        MockServerWebExchange first = exchange("/api/order/1");
        MockServerWebExchange second = exchange("/api/order/2");

        filter.filter(first, chain).block();
        filter.filter(second, chain).block();

        assertEquals(1, downstreamCalls.get());
        assertEquals(HttpStatus.TOO_MANY_REQUESTS, second.getResponse().getStatusCode());
    }

    @Test
    void skipsOptionsPreflight() {
        GatewaySecurityProperties properties = properties(0, 60);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            downstreamCalls.incrementAndGet();
            return Mono.empty();
        };

        filter.filter(MockServerWebExchange.from(MockServerHttpRequest
                .options("/api/order")
                .remoteAddress(new InetSocketAddress("127.0.0.1", 12345))), chain).block();

        assertEquals(1, downstreamCalls.get());
    }

    @Test
    void ignoresForwardedForHeaderByDefault() {
        GatewaySecurityProperties properties = properties(1, 60);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            downstreamCalls.incrementAndGet();
            return Mono.empty();
        };

        filter.filter(exchangeWithForwardedFor("10.0.0.1"), chain).block();
        filter.filter(exchangeWithForwardedFor("10.0.0.2"), chain).block();

        assertEquals(1, downstreamCalls.get());
    }

    @Test
    void canTrustForwardedForHeaderWhenExplicitlyEnabled() {
        GatewaySecurityProperties properties = properties(1, 60);
        properties.setTrustForwardedHeaders(true);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        WebFilterChain chain = exchange -> {
            downstreamCalls.incrementAndGet();
            return Mono.empty();
        };

        filter.filter(exchangeWithForwardedFor("10.0.0.1"), chain).block();
        filter.filter(exchangeWithForwardedFor("10.0.0.2"), chain).block();

        assertEquals(2, downstreamCalls.get());
    }

    @Test
    void gatewayAuthRejectsProtectedApiWithoutBearerToken() {
        GatewaySecurityProperties properties = properties(10, 60);
        enableAuth(properties);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        MockServerWebExchange exchange = exchange("/api/order/1");

        filter.filter(exchange, countingChain(downstreamCalls)).block();

        assertEquals(0, downstreamCalls.get());
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void gatewayAuthAllowsPublicLoginWithoutBearerToken() {
        GatewaySecurityProperties properties = properties(10, 60);
        enableAuth(properties);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();

        filter.filter(postExchange("/api/print/auth/login"), countingChain(downstreamCalls)).block();

        assertEquals(1, downstreamCalls.get());
    }

    @Test
    void gatewayAuthAllowsPublicCaptchaWithoutBearerToken() {
        GatewaySecurityProperties properties = properties(10, 60);
        enableAuth(properties);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();

        filter.filter(exchange("/api/print/auth/captcha"), countingChain(downstreamCalls)).block();

        assertEquals(1, downstreamCalls.get());
    }

    @Test
    void gatewayAuthAllowsPublicActiveStoreWithoutBearerToken() {
        GatewaySecurityProperties properties = properties(10, 60);
        enableAuth(properties);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();

        filter.filter(exchange("/api/print/store/active"), countingChain(downstreamCalls)).block();

        assertEquals(1, downstreamCalls.get());
    }

    @Test
    void gatewayAuthRejectsFullStoreListWithoutBearerToken() {
        GatewaySecurityProperties properties = properties(10, 60);
        enableAuth(properties);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        MockServerWebExchange exchange = exchange("/api/print/store/");

        filter.filter(exchange, countingChain(downstreamCalls)).block();

        assertEquals(0, downstreamCalls.get());
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void gatewayAuthAllowsValidBearerToken() throws Exception {
        GatewaySecurityProperties properties = properties(10, 60);
        enableAuth(properties);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        MockServerWebExchange exchange = getExchangeWithToken("/api/order/1", validToken("user", 9, null));

        filter.filter(exchange, countingChain(downstreamCalls)).block();

        assertEquals(1, downstreamCalls.get());
    }

    @Test
    void gatewayAuthRejectsTamperedBearerToken() throws Exception {
        GatewaySecurityProperties properties = properties(10, 60);
        enableAuth(properties);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        String token = validToken("user", 9, null) + "tampered";
        MockServerWebExchange exchange = getExchangeWithToken("/api/order/1", token);

        filter.filter(exchange, countingChain(downstreamCalls)).block();

        assertEquals(0, downstreamCalls.get());
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void gatewayAuthRejectsTokenIssuedInFuture() throws Exception {
        GatewaySecurityProperties properties = properties(10, 60);
        enableAuth(properties);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        Map<String, Object> claims = userClaims(9);
        claims.put("iat", fixedClock().instant().getEpochSecond() + 300);
        claims.put("exp", fixedClock().instant().getEpochSecond() + 3900);
        MockServerWebExchange exchange = getExchangeWithToken("/api/order/1", tokenWithClaims(claims));

        filter.filter(exchange, countingChain(downstreamCalls)).block();

        assertEquals(0, downstreamCalls.get());
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void gatewayAuthRejectsUserTokenWithoutRole() throws Exception {
        GatewaySecurityProperties properties = properties(10, 60);
        enableAuth(properties);
        GatewaySecurityFilter filter = filter(properties);
        AtomicInteger downstreamCalls = new AtomicInteger();
        Map<String, Object> claims = userClaims(9);
        claims.remove("role");
        MockServerWebExchange exchange = getExchangeWithToken("/api/order/1", tokenWithClaims(claims));

        filter.filter(exchange, countingChain(downstreamCalls)).block();

        assertEquals(0, downstreamCalls.get());
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    private GatewaySecurityProperties properties(int requests, int windowSeconds) {
        GatewaySecurityProperties properties = new GatewaySecurityProperties();
        properties.getRequestLog().setEnabled(false);
        properties.getRateLimit().setEnabled(true);
        properties.getRateLimit().setRequests(requests);
        properties.getRateLimit().setWindowSeconds(windowSeconds);
        return properties;
    }

    private void enableAuth(GatewaySecurityProperties properties) {
        properties.getAuth().setEnabled(true);
        properties.getAuth().setJwtSecret(JWT_SECRET);
    }

    private GatewaySecurityFilter filter(GatewaySecurityProperties properties) {
        return new GatewaySecurityFilter(properties, OBJECT_MAPPER, fixedClock());
    }

    private WebFilterChain countingChain(AtomicInteger downstreamCalls) {
        return exchange -> {
            downstreamCalls.incrementAndGet();
            return Mono.empty();
        };
    }

    private Clock fixedClock() {
        return Clock.fixed(Instant.parse("2026-07-04T00:00:00Z"), ZoneOffset.UTC);
    }

    private MockServerWebExchange exchange(String path) {
        return MockServerWebExchange.from(MockServerHttpRequest
                .get(path)
                .remoteAddress(new InetSocketAddress("127.0.0.1", 12345)));
    }

    private MockServerWebExchange postExchange(String path) {
        return MockServerWebExchange.from(MockServerHttpRequest
                .post(path)
                .remoteAddress(new InetSocketAddress("127.0.0.1", 12345)));
    }

    private MockServerWebExchange getExchangeWithToken(String path, String token) {
        return MockServerWebExchange.from(MockServerHttpRequest
                .get(path)
                .header("Authorization", "Bearer " + token)
                .remoteAddress(new InetSocketAddress("127.0.0.1", 12345)));
    }

    private MockServerWebExchange exchangeWithForwardedFor(String forwardedFor) {
        return MockServerWebExchange.from(MockServerHttpRequest
                .get("/api/order")
                .header("X-Forwarded-For", forwardedFor)
                .remoteAddress(new InetSocketAddress("127.0.0.1", 12345)));
    }

    private String validToken(String type, int id, String role) throws Exception {
        Map<String, Object> claims = userClaims(id);
        claims.put("type", type);
        claims.put("sub", type + ":" + id);
        if (role != null) {
            claims.put("role", role);
        }
        return tokenWithClaims(claims);
    }

    private Map<String, Object> userClaims(int id) {
        long now = fixedClock().instant().getEpochSecond();
        Map<String, Object> claims = new LinkedHashMap<>();
        claims.put("typ", "JWT");
        claims.put("type", "user");
        claims.put("id", id);
        claims.put("sub", "user:" + id);
        claims.put("role", "user");
        claims.put("username", "user-" + id);
        claims.put("iat", now);
        claims.put("exp", now + 3600);
        claims.put("jti", UUID.randomUUID().toString());
        return claims;
    }

    private String tokenWithClaims(Map<String, Object> claims) throws Exception {
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("alg", "HS256");
        header.put("typ", "JWT");
        String headerPart = base64Url(OBJECT_MAPPER.writeValueAsBytes(header));
        String payloadPart = base64Url(OBJECT_MAPPER.writeValueAsBytes(claims));
        String signed = headerPart + "." + payloadPart;
        return signed + "." + base64Url(hmac(signed.getBytes(StandardCharsets.UTF_8)));
    }

    private byte[] hmac(byte[] data) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(JWT_SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return mac.doFinal(data);
    }

    private String base64Url(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
