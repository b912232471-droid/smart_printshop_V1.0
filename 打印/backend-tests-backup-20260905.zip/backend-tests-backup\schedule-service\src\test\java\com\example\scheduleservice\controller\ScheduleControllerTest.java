package com.example.scheduleservice.controller;

import com.example.scheduleservice.common.GlobalExceptionHandler;
import com.example.scheduleservice.dto.BindRequest;
import com.example.scheduleservice.dto.BindStatusResponse;
import com.example.scheduleservice.dto.CourseScheduleResponse;
import com.example.scheduleservice.security.JwtAuthFilter;
import com.example.scheduleservice.security.JwtService;
import com.example.scheduleservice.security.ScheduleSecurityProperties;
import com.example.scheduleservice.service.ScheduleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class ScheduleControllerTest {
    private static final String JWT_SECRET = "schedule-jwt-secret-with-more-than-32-characters";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private ScheduleService scheduleService;
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        scheduleService = mock(ScheduleService.class);
        ScheduleController controller = new ScheduleController(scheduleService);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .addFilters(authFilter())
                .build();
    }

    @Test
    void protectedRoutesRejectMissingBearerToken() throws Exception {
        mockMvc.perform(get("/api/schedule/bind-status"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value(401))
                .andExpect(jsonPath("$.message").value("unauthorized"));
    }

    @Test
    void bindUsesAuthenticatedUserIdAndDoesNotExposePasswordField() throws Exception {
        when(scheduleService.bind(eq(101L), any(BindRequest.class)))
                .thenReturn(new BindStatusResponse(true, "20260001"));

        mockMvc.perform(post("/api/schedule/bind")
                        .header("Authorization", "Bearer " + validUserToken(101))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "studentId": "20260001",
                                  "jwPassword": "secret-password"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.bound").value(true))
                .andExpect(jsonPath("$.studentId").value("20260001"))
                .andExpect(jsonPath("$.jwPassword").doesNotExist());

        verify(scheduleService).bind(eq(101L), any(BindRequest.class));
    }

    @Test
    void schedulesUseAuthenticatedUserId() throws Exception {
        when(scheduleService.schedules(102L, "2025-2026", "1"))
                .thenReturn(List.of(new CourseScheduleResponse(
                        "20260002",
                        "2025-2026",
                        "1",
                        "示例课程",
                        "1",
                        "1-2",
                        "教学楼101",
                        "授课教师"
                )));

        mockMvc.perform(get("/api/schedule?xnm=2025-2026&xqm=1")
                        .header("Authorization", "Bearer " + validUserToken(102)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].studentId").value("20260002"))
                .andExpect(jsonPath("$[0].kcmc").value("示例课程"));

        verify(scheduleService).schedules(102L, "2025-2026", "1");
    }

    private JwtAuthFilter authFilter() {
        ScheduleSecurityProperties properties = new ScheduleSecurityProperties();
        properties.getAuth().setEnabled(true);
        properties.getAuth().setJwtSecret(JWT_SECRET);
        return new JwtAuthFilter(properties, new JwtService(properties, OBJECT_MAPPER));
    }

    private String validUserToken(long userId) throws Exception {
        long now = Instant.now().getEpochSecond();
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("alg", "HS256");
        header.put("typ", "JWT");
        Map<String, Object> claims = new LinkedHashMap<>();
        claims.put("typ", "JWT");
        claims.put("type", "user");
        claims.put("id", userId);
        claims.put("sub", "user:" + userId);
        claims.put("role", "user");
        claims.put("username", "user-" + userId);
        claims.put("iat", now);
        claims.put("exp", now + 3600);
        claims.put("jti", UUID.randomUUID().toString());

        String headerPart = base64Url(OBJECT_MAPPER.writeValueAsBytes(header));
        String payloadPart = base64Url(OBJECT_MAPPER.writeValueAsBytes(claims));
        String signed = headerPart + "." + payloadPart;
        return signed + "." + base64Url(hmac(signed.getBytes(StandardCharsets.UTF_8)));
    }

    private byte[] hmac(byte[] data) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(JWT_SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return mac.doFinal(data);
    }

    private String base64Url(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
