package com.example.scheduleservice.service.sync;

import com.example.scheduleservice.model.CourseSchedule;
import com.example.scheduleservice.model.JwAccount;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@EnabledIfEnvironmentVariable(named = "ZFSOFT_LIVE_TEST", matches = "true")
class ZfsoftLiveSyncIT {
    @Test
    void fetchesRealScheduleFromProductionJwSystem() {
        String baseUrl = System.getenv("ZFSOFT_LIVE_BASE_URL");
        String studentId = System.getenv("ZFSOFT_LIVE_STUDENT_ID");
        String password = System.getenv("ZFSOFT_LIVE_PASSWORD");
        String xnm = System.getenv().getOrDefault("ZFSOFT_LIVE_XNM", "2026-2027");
        String xqm = System.getenv().getOrDefault("ZFSOFT_LIVE_XQM", "1");

        ZfsoftScheduleSyncAdapter adapter = new ZfsoftScheduleSyncAdapter(true, baseUrl, "N253508", 20000);
        List<CourseSchedule> courses = adapter.fetchCourses(
                7L, new JwAccount(1L, 7L, studentId, password), password, xnm, xqm);

        System.out.println("fetched courses: " + courses.size());
        courses.forEach(course -> System.out.println(
                course.kcmc() + " 周" + course.xqj() + " 第" + course.jcs() + "节 " + course.cdmc() + " " + course.xm()));
        assertTrue(courses.size() > 0, "应当至少同步到一门课程");
    }
}
