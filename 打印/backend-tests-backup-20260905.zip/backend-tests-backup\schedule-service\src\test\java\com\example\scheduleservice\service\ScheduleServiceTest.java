package com.example.scheduleservice.service;

import com.example.scheduleservice.common.ApiException;
import com.example.scheduleservice.dto.BindRequest;
import com.example.scheduleservice.dto.SyncRequest;
import com.example.scheduleservice.model.CourseSchedule;
import com.example.scheduleservice.model.JwAccount;
import com.example.scheduleservice.repository.CourseScheduleRepository;
import com.example.scheduleservice.repository.JwAccountRepository;
import com.example.scheduleservice.security.FieldCryptoService;
import com.example.scheduleservice.security.ScheduleSecurityProperties;
import com.example.scheduleservice.service.sync.HttpJsonScheduleSyncAdapter;
import com.example.scheduleservice.service.sync.ScheduleSyncAdapter;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ScheduleServiceTest {
    @Test
    void bindEncryptsJwPasswordBeforeSaving() {
        JwAccountRepository accountRepository = mock(JwAccountRepository.class);
        CourseScheduleRepository courseRepository = mock(CourseScheduleRepository.class);
        ScheduleService service = new ScheduleService(accountRepository, courseRepository, cryptoService(), syncAdapter(false), false);
        when(accountRepository.findByUserId(7L)).thenReturn(Optional.of(account("20260001")));

        service.bind(7L, new BindRequest("20260001", "secret-password"));

        ArgumentCaptor<String> passwordCaptor = ArgumentCaptor.forClass(String.class);
        verify(accountRepository).saveOrUpdate(
                eq(7L),
                eq("20260001"),
                passwordCaptor.capture()
        );
        assertNotEquals("secret-password", passwordCaptor.getValue());
        assertTrue(passwordCaptor.getValue().startsWith("ENC:v1:"));
    }

    @Test
    void syncReturnsUnavailableWhenAdapterIsNotConfigured() {
        JwAccountRepository accountRepository = mock(JwAccountRepository.class);
        CourseScheduleRepository courseRepository = mock(CourseScheduleRepository.class);
        ScheduleService service = new ScheduleService(accountRepository, courseRepository, cryptoService(), syncAdapter(false), false);
        when(accountRepository.findByUserId(7L)).thenReturn(Optional.of(account("20260001")));

        ApiException exception = assertThrows(
                ApiException.class,
                () -> service.sync(7L, new SyncRequest("2025-2026", "1"))
        );

        assertEquals(503, exception.getStatus());
        assertEquals("教务同步适配器未配置", exception.getMessage());
    }

    @Test
    void mockSyncImportsSampleCourseForLocalDevelopmentOnly() {
        JwAccountRepository accountRepository = mock(JwAccountRepository.class);
        CourseScheduleRepository courseRepository = mock(CourseScheduleRepository.class);
        ScheduleService service = new ScheduleService(accountRepository, courseRepository, cryptoService(), syncAdapter(false), true);
        when(accountRepository.findByUserId(7L)).thenReturn(Optional.of(account("20260001")));

        var response = service.sync(7L, new SyncRequest("2025-2026", "1"));

        assertEquals(1, response.imported());
        ArgumentCaptor<List<CourseSchedule>> coursesCaptor = ArgumentCaptor.captor();
        verify(courseRepository).replaceTerm(
                eq(7L),
                eq("20260001"),
                eq("2025-2026"),
                eq("1"),
                coursesCaptor.capture()
        );
        assertEquals("示例课程", coursesCaptor.getValue().get(0).kcmc());
    }

    @Test
    void httpAdapterImportsCoursesFromConfiguredEducationSystem() throws Exception {
        AtomicReference<String> requestBody = new AtomicReference<>();
        AtomicReference<String> authHeader = new AtomicReference<>();
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/sync", exchange -> {
            requestBody.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            authHeader.set(exchange.getRequestHeaders().getFirst("Authorization"));
            byte[] body = """
                    {
                      "xnm": "2025-2026",
                      "xqm": "1",
                      "courses": [
                        {"kcmc": "高等数学", "xqj": "1", "jcs": "1-2", "cdmc": "教学楼201", "xm": "王老师"},
                        {"kcmc": "大学英语", "xqj": "3", "jcs": "5-6", "cdmc": "教学楼301", "xm": "李老师"}
                      ]
                    }
                    """.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, body.length);
            exchange.getResponseBody().write(body);
            exchange.close();
        });
        server.start();
        try {
            FieldCryptoService cryptoService = cryptoService();
            JwAccountRepository accountRepository = mock(JwAccountRepository.class);
            CourseScheduleRepository courseRepository = mock(CourseScheduleRepository.class);
            String endpoint = "http://127.0.0.1:" + server.getAddress().getPort() + "/sync";
            ScheduleService service = new ScheduleService(
                    accountRepository,
                    courseRepository,
                    cryptoService,
                    new HttpJsonScheduleSyncAdapter(true, endpoint, "adapter-token", 2000),
                    false
            );
            when(accountRepository.findByUserId(7L)).thenReturn(Optional.of(encryptedAccount("20260001", cryptoService)));

            var response = service.sync(7L, new SyncRequest("2025-2026", "1"));

            assertEquals(2, response.imported());
            assertEquals("Bearer adapter-token", authHeader.get());
            assertTrue(requestBody.get().contains("\"jwPassword\":\"secret-password\""));
            assertFalse(requestBody.get().contains("ENC:v1:"));
            ArgumentCaptor<List<CourseSchedule>> coursesCaptor = ArgumentCaptor.captor();
            verify(courseRepository).replaceTerm(
                    eq(7L),
                    eq("20260001"),
                    eq("2025-2026"),
                    eq("1"),
                    coursesCaptor.capture()
            );
            assertEquals("高等数学", coursesCaptor.getValue().get(0).kcmc());
            assertEquals("大学英语", coursesCaptor.getValue().get(1).kcmc());
        } finally {
            server.stop(0);
        }
    }

    private JwAccount account(String studentId) {
        return new JwAccount(1, 7, studentId, "ENC:v1:stored");
    }

    private JwAccount encryptedAccount(String studentId, FieldCryptoService cryptoService) {
        return new JwAccount(1, 7, studentId, cryptoService.encrypt("secret-password"));
    }

    private FieldCryptoService cryptoService() {
        ScheduleSecurityProperties properties = new ScheduleSecurityProperties();
        properties.setFieldEncryptionKey("schedule-field-encryption-key-with-32-bytes");
        return new FieldCryptoService(properties);
    }

    private ScheduleSyncAdapter syncAdapter(boolean configured) {
        return new ScheduleSyncAdapter() {
            @Override
            public boolean isConfigured() {
                return configured;
            }

            @Override
            public List<CourseSchedule> fetchCourses(long userId, JwAccount account, String jwPassword, String xnm, String xqm) {
                return List.of();
            }
        };
    }
}
