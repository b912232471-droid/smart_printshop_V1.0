package com.example.printshop.controller;

import com.example.printshop.entity.User;
import com.example.printshop.security.AuthContext;
import com.example.printshop.security.AuthPrincipal;
import com.example.printshop.service.UserService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class UserControllerTest {
    private UserService userService;
    private UserController controller;

    @BeforeEach
    void setUp() {
        userService = mock(UserService.class);
        controller = new UserController();
        ReflectionTestUtils.setField(controller, "userService", userService);
    }

    @AfterEach
    void tearDown() {
        AuthContext.clear();
    }

    @Test
    void userUpdateCannotOverwriteLoginTimestamps() {
        AuthContext.set(userPrincipal(7));
        User existing = user(7);
        when(userService.getUserById(7)).thenReturn(existing);
        doAnswer(invocation -> {
            User updated = invocation.getArgument(0, User.class);
            assertEquals("2026-01-01 10:00:00", updated.getRegisterTime());
            assertEquals("2026-01-02 10:00:00", updated.getLastLoginTime());
            assertEquals("new-name", updated.getUsername());
            return 1;
        }).when(userService).updateUser(any(User.class));

        User request = new User();
        request.setId(7);
        request.setRegisterTime("2099-01-01 00:00:00");
        request.setLastLoginTime("2099-01-01 00:00:00");
        request.setUsername("new-name");

        int rows = controller.updateUser(request);

        assertEquals(1, rows);
    }

    @Test
    void userDetailReturnsPublicProfile() {
        AuthContext.set(userPrincipal(7));
        when(userService.getUserById(7)).thenReturn(user(7));

        User result = controller.getUser(7);

        assertEquals(7, result.getId());
        assertEquals("old-name", result.getUsername());
    }

    @Test
    void adminUserListReturnsPublicProfiles() {
        AuthContext.set(adminPrincipal(1));
        when(userService.getAllUsers()).thenReturn(List.of(user(7)));

        List<User> result = controller.getAllUsers();

        assertEquals(1, result.size());
        assertEquals("old-name", result.get(0).getUsername());
    }

    private User user(Integer id) {
        User user = new User();
        user.setId(id);
        user.setUsername("old-name");
        user.setRegisterTime("2026-01-01 10:00:00");
        user.setLastLoginTime("2026-01-02 10:00:00");
        return user;
    }

    private AuthPrincipal userPrincipal(Integer id) {
        AuthPrincipal principal = new AuthPrincipal();
        principal.setId(id);
        principal.setType("user");
        principal.setSubject("user:" + id);
        return principal;
    }

    private AuthPrincipal adminPrincipal(Integer id) {
        AuthPrincipal principal = new AuthPrincipal();
        principal.setId(id);
        principal.setType("admin");
        principal.setRole("admin");
        principal.setSubject("admin:" + id);
        return principal;
    }
}
