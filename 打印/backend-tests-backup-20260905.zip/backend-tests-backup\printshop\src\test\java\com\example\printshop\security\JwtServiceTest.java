package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import com.example.printshop.entity.Admin;
import com.example.printshop.entity.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class JwtServiceTest {
    private static final String SECRET = "test-secret-with-more-than-32-characters";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Test
    void createsAndParsesAdminToken() {
        JwtService jwtService = new JwtService(new ObjectMapper(), SECRET, 3600, 3600);
        Admin admin = new Admin();
        admin.setId(7);
        admin.setUsername("root");
        admin.setRole("superadmin");

        JwtService.TokenPair tokenPair = jwtService.createAdminToken(admin);
        AuthPrincipal principal = jwtService.parse(tokenPair.token());

        assertEquals(7, principal.getId());
        assertEquals("admin", principal.getType());
        assertEquals("superadmin", principal.getRole());
        assertEquals("root", principal.getUsername());
        assertTrue(tokenPair.expiresIn() > 0);
    }

    @Test
    void rejectsTamperedToken() {
        JwtService jwtService = new JwtService(new ObjectMapper(), SECRET, 3600, 3600);
        User user = new User();
        user.setId(11);
        user.setUsername("student");
        String token = jwtService.createUserToken(user).token();
        String tampered = token.substring(0, token.length() - 1) + (token.endsWith("a") ? "b" : "a");

        ApiException exception = assertThrows(ApiException.class, () -> jwtService.parse(tampered));

        assertEquals(401, exception.getStatus());
    }

    @Test
    void rejectsExpiredToken() {
        JwtService jwtService = new JwtService(new ObjectMapper(), SECRET, 3600, 0);
        User user = new User();
        user.setId(11);

        ApiException exception = assertThrows(ApiException.class, () -> jwtService.parse(jwtService.createUserToken(user).token()));

        assertEquals(401, exception.getStatus());
        assertEquals("token expired", exception.getMessage());
    }

    @Test
    void requiresStrongSecret() {
        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> new JwtService(new ObjectMapper(), "short", 3600, 3600)
        );

        assertTrue(exception.getMessage().contains("PRINTSHOP_JWT_SECRET"));
    }

    @Test
    void rejectsKnownDevelopmentSecret() {
        assertThrows(
                IllegalStateException.class,
                () -> new JwtService(new ObjectMapper(), "dev-only-local-jwt-secret-please-replace-before-production", 3600, 3600)
        );
    }

    @Test
    void rejectsUnexpectedJwtHeaderBeforeTrustingPayload() {
        JwtService jwtService = new JwtService(new ObjectMapper(), SECRET, 3600, 3600);
        User user = new User();
        user.setId(11);
        String token = jwtService.createUserToken(user).token();
        String[] parts = token.split("\\.");
        String noneHeader = Base64.getUrlEncoder().withoutPadding()
                .encodeToString("{\"alg\":\"none\",\"typ\":\"JWT\"}".getBytes(StandardCharsets.UTF_8));

        ApiException exception = assertThrows(ApiException.class, () -> jwtService.parse(noneHeader + "." + parts[1] + "." + parts[2]));

        assertEquals(401, exception.getStatus());
        assertEquals("invalid token header", exception.getMessage());
    }

    @Test
    void rejectsTokenIssuedInFuture() throws Exception {
        JwtService jwtService = new JwtService(OBJECT_MAPPER, SECRET, 3600, 3600);
        Map<String, Object> claims = userClaims(11);
        long future = Instant.now().getEpochSecond() + 300;
        claims.put("iat", future);
        claims.put("exp", future + 3600);

        ApiException exception = assertThrows(ApiException.class, () -> jwtService.parse(sign(claims)));

        assertEquals(401, exception.getStatus());
        assertEquals("invalid token claims", exception.getMessage());
    }

    @Test
    void rejectsUserTokenWithoutRole() throws Exception {
        JwtService jwtService = new JwtService(OBJECT_MAPPER, SECRET, 3600, 3600);
        Map<String, Object> claims = userClaims(11);
        claims.remove("role");

        ApiException exception = assertThrows(ApiException.class, () -> jwtService.parse(sign(claims)));

        assertEquals(401, exception.getStatus());
        assertEquals("invalid account token", exception.getMessage());
    }

    @Test
    void rejectsTokenWithoutUuidJti() throws Exception {
        JwtService jwtService = new JwtService(OBJECT_MAPPER, SECRET, 3600, 3600);
        Map<String, Object> claims = userClaims(11);
        claims.put("jti", "not-a-uuid");

        ApiException exception = assertThrows(ApiException.class, () -> jwtService.parse(sign(claims)));

        assertEquals(401, exception.getStatus());
        assertEquals("invalid token claims", exception.getMessage());
    }

    private Map<String, Object> userClaims(int userId) {
        long now = Instant.now().getEpochSecond();
        Map<String, Object> claims = new LinkedHashMap<>();
        claims.put("typ", "JWT");
        claims.put("type", "user");
        claims.put("id", userId);
        claims.put("sub", "user:" + userId);
        claims.put("role", "user");
        claims.put("username", "student-" + userId);
        claims.put("iat", now);
        claims.put("exp", now + 3600);
        claims.put("jti", UUID.randomUUID().toString());
        return claims;
    }

    private String sign(Map<String, Object> claims) throws Exception {
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("alg", "HS256");
        header.put("typ", "JWT");
        String headerPart = base64Url(OBJECT_MAPPER.writeValueAsBytes(header));
        String payloadPart = base64Url(OBJECT_MAPPER.writeValueAsBytes(claims));
        String signed = headerPart + "." + payloadPart;
        return signed + "." + base64Url(hmac(signed.getBytes(StandardCharsets.UTF_8)));
    }

    private byte[] hmac(byte[] data) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return mac.doFinal(data);
    }

    private String base64Url(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
