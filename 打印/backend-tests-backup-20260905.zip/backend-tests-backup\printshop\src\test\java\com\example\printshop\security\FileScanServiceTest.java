package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class FileScanServiceTest {
    @Test
    void disabledScannerAllowsFile() {
        FileScanService service = new FileScanService(false, "127.0.0.1", 1, 100, true);

        assertDoesNotThrow(() -> service.scan(file()));
    }

    @Test
    void cleanClamAvResponseAllowsFile() throws Exception {
        try (MockClamAvServer server = new MockClamAvServer("stream: OK\n")) {
            FileScanService service = new FileScanService(true, "127.0.0.1", server.port(), 2000, true);

            assertDoesNotThrow(() -> service.scan(file()));
            server.awaitRequest();
        }
    }

    @Test
    void infectedClamAvResponseRejectsFile() throws Exception {
        try (MockClamAvServer server = new MockClamAvServer("stream: Eicar-Test-Signature FOUND\n")) {
            FileScanService service = new FileScanService(true, "127.0.0.1", server.port(), 2000, true);

            ApiException exception = assertThrows(ApiException.class, () -> service.scan(file()));

            assertEquals(400, exception.getStatus());
            assertEquals("文件安全扫描未通过", exception.getMessage());
            server.awaitRequest();
        }
    }

    @Test
    void unavailableScannerFailsClosed() {
        FileScanService service = new FileScanService(true, "127.0.0.1", 1, 100, true);

        ApiException exception = assertThrows(ApiException.class, () -> service.scan(file()));

        assertEquals(503, exception.getStatus());
    }

    @Test
    void unavailableScannerCanFailOpenForDevelopment() {
        FileScanService service = new FileScanService(true, "127.0.0.1", 1, 100, false);

        assertDoesNotThrow(() -> service.scan(file()));
    }

    private MockMultipartFile file() {
        return new MockMultipartFile("file", "safe.txt", "text/plain", "hello".getBytes(StandardCharsets.UTF_8));
    }

    private static class MockClamAvServer implements AutoCloseable {
        private final ServerSocket serverSocket;
        private final CountDownLatch requestHandled = new CountDownLatch(1);
        private final Thread thread;

        MockClamAvServer(String response) throws IOException {
            serverSocket = new ServerSocket(0);
            thread = new Thread(() -> handle(response), "mock-clamav");
            thread.start();
        }

        int port() {
            return serverSocket.getLocalPort();
        }

        void awaitRequest() throws InterruptedException {
            requestHandled.await(2, TimeUnit.SECONDS);
        }

        private void handle(String response) {
            try (Socket socket = serverSocket.accept();
                 DataInputStream input = new DataInputStream(socket.getInputStream())) {
                readCommand(input);
                while (true) {
                    int length = input.readInt();
                    if (length == 0) {
                        break;
                    }
                    input.readNBytes(length);
                }
                socket.getOutputStream().write(response.getBytes(StandardCharsets.UTF_8));
                socket.getOutputStream().flush();
            } catch (IOException ignored) {
            } finally {
                requestHandled.countDown();
            }
        }

        private void readCommand(DataInputStream input) throws IOException {
            while (input.readByte() != 0) {
                // read until zINSTREAM terminator
            }
        }

        @Override
        public void close() throws IOException {
            serverSocket.close();
        }
    }
}
