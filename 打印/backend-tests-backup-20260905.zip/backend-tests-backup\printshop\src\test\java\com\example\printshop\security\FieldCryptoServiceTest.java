package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FieldCryptoServiceTest {
    private final FieldCryptoService cryptoService = new FieldCryptoService("test-field-crypto-key-with-more-than-32-characters");

    @Test
    void encryptsAndDecryptsFieldValue() {
        String encrypted = cryptoService.encryptNullable("13800000000");

        assertTrue(encrypted.startsWith("ENC:v1:"));
        assertNotEquals("13800000000", encrypted);
        assertEquals("13800000000", cryptoService.decryptNullable(encrypted));
    }

    @Test
    void keepsLegacyPlaintextReadable() {
        assertEquals("13800000000", cryptoService.decryptNullable("13800000000"));
    }

    @Test
    void rejectsWeakFieldKey() {
        assertThrows(IllegalStateException.class, () -> new FieldCryptoService("short"));
    }

    @Test
    void rejectsTamperedCiphertext() {
        String encrypted = cryptoService.encryptNullable("13800000000");
        String tampered = encrypted.substring(0, encrypted.length() - 1) + (encrypted.endsWith("A") ? "B" : "A");

        assertThrows(ApiException.class, () -> cryptoService.decryptNullable(tampered));
    }
}
