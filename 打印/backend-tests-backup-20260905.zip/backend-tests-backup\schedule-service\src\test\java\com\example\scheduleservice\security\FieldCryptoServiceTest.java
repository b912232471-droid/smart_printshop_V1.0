package com.example.scheduleservice.security;

import com.example.scheduleservice.common.ApiException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FieldCryptoServiceTest {
    @Test
    void encryptsAndDecryptsSensitiveValue() {
        FieldCryptoService cryptoService = new FieldCryptoService(properties());

        String encrypted = cryptoService.encrypt("student-password");

        assertTrue(encrypted.startsWith("ENC:v1:"));
        assertNotEquals("student-password", encrypted);
        assertEquals("student-password", cryptoService.decrypt(encrypted));
    }

    @Test
    void rejectsTamperedCipherText() {
        FieldCryptoService cryptoService = new FieldCryptoService(properties());
        String encrypted = cryptoService.encrypt("student-password");

        assertThrows(ApiException.class, () -> cryptoService.decrypt(encrypted + "tampered"));
    }

    private ScheduleSecurityProperties properties() {
        ScheduleSecurityProperties properties = new ScheduleSecurityProperties();
        properties.setFieldEncryptionKey("schedule-field-encryption-key-with-32-bytes");
        return properties;
    }
}
