package com.example.printshop.service.impl;

import com.example.printshop.common.ApiException;
import com.example.printshop.entity.Admin;
import com.example.printshop.mapper.AdminMapper;
import com.example.printshop.security.FieldCryptoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AdminServiceImplTest {
    private AdminMapper adminMapper;
    private BCryptPasswordEncoder passwordEncoder;
    private FieldCryptoService fieldCryptoService;
    private AdminServiceImpl service;

    @BeforeEach
    void setUp() {
        adminMapper = mock(AdminMapper.class);
        passwordEncoder = new BCryptPasswordEncoder();
        fieldCryptoService = new FieldCryptoService("test-field-crypto-key-with-more-than-32-characters");
        service = new AdminServiceImpl();
        ReflectionTestUtils.setField(service, "adminMapper", adminMapper);
        ReflectionTestUtils.setField(service, "passwordEncoder", passwordEncoder);
        ReflectionTestUtils.setField(service, "fieldCryptoService", fieldCryptoService);
    }

    @Test
    void loginMigratesLegacyPlaintextPasswordToBcrypt() {
        Admin admin = enabledAdmin("123456@qq.com", "legacy-password");
        AtomicReference<String> passwordAtUpdate = new AtomicReference<>();
        when(adminMapper.selectByEmailHash(emailHash("123456@qq.com"))).thenReturn(admin);
        doAnswer(invocation -> {
            passwordAtUpdate.set(invocation.getArgument(0, Admin.class).getPassword());
            return 1;
        }).when(adminMapper).update(any(Admin.class));

        Admin result = service.login("123456@qq.com", "legacy-password");

        verify(adminMapper).updateLastLoginTime(1);
        assertTrue(passwordAtUpdate.get().startsWith("$2"));
        assertTrue(passwordEncoder.matches("legacy-password", passwordAtUpdate.get()));
        assertNull(result.getPassword());
    }

    @Test
    void loginDoesNotRewriteExistingBcryptPassword() {
        Admin admin = enabledAdmin("123456@qq.com", passwordEncoder.encode("safe-password"));
        when(adminMapper.selectByEmailHash(emailHash("123456@qq.com"))).thenReturn(admin);

        Admin result = service.login("123456@qq.com", "safe-password");

        verify(adminMapper).updateLastLoginTime(1);
        verify(adminMapper, never()).update(any(Admin.class));
        assertNull(result.getPassword());
    }

    @Test
    void registerHashesPasswordAndSetsDefaults() {
        Admin admin = new Admin();
        admin.setPassword("new-password1");
        admin.setPhone("13800000000");
        admin.setEmail("123456@qq.com");
        AtomicReference<Admin> inserted = new AtomicReference<>();
        when(adminMapper.selectByEmailHash(emailHash("123456@qq.com"))).thenReturn(null);
        doAnswer(invocation -> {
            inserted.set(invocation.getArgument(0, Admin.class));
            return 1;
        }).when(adminMapper).insert(any(Admin.class));

        assertEquals(1, service.register(admin));
        assertEquals("123456@qq.com", inserted.get().getUsername());
        assertEquals("admin", inserted.get().getRole());
        assertEquals(1, inserted.get().getStatus());
        assertTrue(passwordEncoder.matches("new-password1", inserted.get().getPassword()));
        assertTrue(inserted.get().getPhone().startsWith("ENC:v1:"));
        assertTrue(inserted.get().getEmail().startsWith("ENC:v1:"));
    }

    @Test
    void registerRejectsWeakPassword() {
        Admin admin = new Admin();
        admin.setEmail("123456@qq.com");
        admin.setPassword("12345678");

        ApiException exception = assertThrows(ApiException.class, () -> service.register(admin));

        assertEquals(400, exception.getStatus());
        verify(adminMapper, never()).insert(any(Admin.class));
    }

    @Test
    void registerRejectsInvalidRole() {
        Admin admin = new Admin();
        admin.setEmail("123456@qq.com");
        admin.setPassword("new-password1");
        admin.setRole("root");

        ApiException exception = assertThrows(ApiException.class, () -> service.register(admin));

        assertEquals(400, exception.getStatus());
        verify(adminMapper, never()).insert(any(Admin.class));
    }

    @Test
    void updateRejectsDuplicateEmail() {
        Admin admin = enabledAdmin("123456@qq.com", null);
        admin.setId(2);
        Admin existing = enabledAdmin("123456@qq.com", null);
        when(adminMapper.selectByEmailHash(emailHash("123456@qq.com"))).thenReturn(existing);

        ApiException exception = assertThrows(ApiException.class, () -> service.update(admin));

        assertEquals(400, exception.getStatus());
        verify(adminMapper, never()).update(any(Admin.class));
    }

    @Test
    void updateRejectsInvalidStatus() {
        Admin admin = enabledAdmin("123456@qq.com", null);
        admin.setId(2);
        admin.setStatus(2);

        ApiException exception = assertThrows(ApiException.class, () -> service.update(admin));

        assertEquals(400, exception.getStatus());
        verify(adminMapper, never()).update(any(Admin.class));
    }

    private Admin enabledAdmin(String email, String password) {
        Admin admin = new Admin();
        admin.setId(1);
        admin.setUsername(email);
        admin.setEmail(email);
        admin.setPassword(password);
        admin.setRole("superadmin");
        admin.setStatus(1);
        return admin;
    }

    private String emailHash(String email) {
        return fieldCryptoService.blindIndex(email);
    }
}
