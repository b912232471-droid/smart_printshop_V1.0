package com.example.printshop.controller;

import com.example.printshop.common.ApiException;
import com.example.printshop.entity.FileInfo;
import com.example.printshop.entity.OrderInfo;
import com.example.printshop.security.AuthContext;
import com.example.printshop.security.AuthPrincipal;
import com.example.printshop.security.FileScanService;
import com.example.printshop.security.ImageContentModerationService;
import com.example.printshop.service.FileInfoService;
import com.example.printshop.service.OrderInfoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.encryption.StandardProtectionPolicy;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class FileInfoControllerTest {
    private final FileInfoController controller = new FileInfoController(
            null,
            null,
            "",
            new FileScanService(false, "127.0.0.1", 3310, 1000, true),
            disabledImageModeration(),
            2000,
            20 * 1024 * 1024,
            100 * 1024 * 1024,
            200,
            true,
            10000,
            64,
            2 * 1024 * 1024,
            20 * 1024 * 1024,
            10000,
            10000,
            40_000_000
    );

    @AfterEach
    void tearDown() {
        AuthContext.clear();
    }

    @Test
    void acceptsPdfWhenParserAcceptsDocumentWithinPageLimit() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.pdf",
                "application/pdf",
                pdf(2)
        );

        ReflectionTestUtils.invokeMethod(controller, "validateFile", file, Set.of(".pdf"));
    }

    @Test
    void rejectsPdfWhenPageCountExceedsLimit() throws Exception {
        FileInfoController strictController = controllerWithLimits(
                2000,
                20 * 1024 * 1024,
                100 * 1024 * 1024,
                1,
                true,
                10000,
                10000,
                40_000_000
        );
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.pdf",
                "application/pdf",
                pdf(2)
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(strictController, "validateFile", file, Set.of(".pdf"))
        );

        assertEquals(400, exception.getStatus());
        assertEquals("文件内容与扩展名不匹配", exception.getMessage());
    }

    @Test
    void rejectsEncryptedPdfByDefault() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.pdf",
                "application/pdf",
                encryptedPdf()
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(controller, "validateFile", file, Set.of(".pdf"))
        );

        assertEquals(400, exception.getStatus());
        assertEquals("文件内容与扩展名不匹配", exception.getMessage());
    }

    @Test
    void rejectsPdfWhenObjectCountExceedsLimit() throws Exception {
        FileInfoController strictController = controllerWithPdfLimits(200, true, 1, 64, 2 * 1024 * 1024, 20 * 1024 * 1024);
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.pdf",
                "application/pdf",
                pdf(1)
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(strictController, "validateFile", file, Set.of(".pdf"))
        );

        assertEquals(400, exception.getStatus());
        assertEquals("文件内容与扩展名不匹配", exception.getMessage());
    }

    @Test
    void rejectsPdfWhenContentStreamBytesExceedLimit() throws Exception {
        FileInfoController strictController = controllerWithPdfLimits(200, true, 10000, 64, 16, 16);
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.pdf",
                "application/pdf",
                pdfWithContentBytes(64)
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(strictController, "validateFile", file, Set.of(".pdf"))
        );

        assertEquals(400, exception.getStatus());
        assertEquals("文件内容与扩展名不匹配", exception.getMessage());
    }

    @Test
    void rejectsSpoofedImageExtension() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "image.png",
                "image/png",
                "not a png".getBytes(StandardCharsets.US_ASCII)
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(controller, "validateFile", file, Set.of(".png"))
        );

        assertEquals(400, exception.getStatus());
        assertEquals("文件内容与扩展名不匹配", exception.getMessage());
    }

    @Test
    void acceptsImageWhenDimensionsAreWithinLimits() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "image.png",
                "image/png",
                png(2, 2)
        );

        ReflectionTestUtils.invokeMethod(controller, "validateFile", file, Set.of(".png"));
    }

    @Test
    void imageUploadsRunContentModeration() throws Exception {
        ImageContentModerationService moderationService = mock(ImageContentModerationService.class);
        FileInfoController securedController = controllerWithModeration(moderationService);
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "image.png",
                "image/png",
                png(2, 2)
        );
        doNothing().when(moderationService).moderate(file);

        ReflectionTestUtils.invokeMethod(securedController, "validateFile", file, Set.of(".png"));

        verify(moderationService).moderate(file);
    }

    @Test
    void nonImageUploadsDoNotRunContentModeration() {
        ImageContentModerationService moderationService = mock(ImageContentModerationService.class);
        FileInfoController securedController = controllerWithModeration(moderationService);
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "notes.txt",
                "text/plain",
                "hello".getBytes(StandardCharsets.UTF_8)
        );

        ReflectionTestUtils.invokeMethod(securedController, "validateFile", file, Set.of(".txt"));

        verify(moderationService, never()).moderate(file);
    }

    @Test
    void rejectsImageWhenPixelCountExceedsLimit() throws Exception {
        FileInfoController strictController = controllerWithLimits(
                2000,
                20 * 1024 * 1024,
                100 * 1024 * 1024,
                200,
                true,
                10000,
                10000,
                2
        );
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "image.png",
                "image/png",
                png(2, 2)
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(strictController, "validateFile", file, Set.of(".png"))
        );

        assertEquals(400, exception.getStatus());
        assertEquals("文件内容与扩展名不匹配", exception.getMessage());
    }

    @Test
    void acceptsDocxOnlyWhenZipHasWordStructure() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                openXml("word/document.xml")
        );

        ReflectionTestUtils.invokeMethod(controller, "validateFile", file, Set.of(".docx"));
    }

    @Test
    void rejectsOpenXmlWithPathTraversalEntry() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                openXml("word/document.xml", "../evil.xml", 8)
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(controller, "validateFile", file, Set.of(".docx"))
        );

        assertEquals(400, exception.getStatus());
        assertEquals("文件内容与扩展名不匹配", exception.getMessage());
    }

    @Test
    void rejectsOpenXmlWhenEntryCountExceedsLimit() throws Exception {
        FileInfoController strictController = controllerWithLimits(1, 20 * 1024 * 1024, 100 * 1024 * 1024, 200, true, 10000, 10000, 40_000_000);
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                openXml("word/document.xml")
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(strictController, "validateFile", file, Set.of(".docx"))
        );

        assertEquals(400, exception.getStatus());
    }

    @Test
    void rejectsOpenXmlWhenUncompressedEntryIsTooLarge() throws Exception {
        FileInfoController strictController = controllerWithLimits(2000, 16, 100 * 1024 * 1024, 200, true, 10000, 10000, 40_000_000);
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                openXml("word/document.xml", null, 64)
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(strictController, "validateFile", file, Set.of(".docx"))
        );

        assertEquals(400, exception.getStatus());
    }

    @Test
    void rejectsOpenXmlWithMacroProject() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                openXml("word/document.xml", "word/vbaProject.bin", "macro")
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(controller, "validateFile", file, Set.of(".docx"))
        );

        assertEquals(400, exception.getStatus());
    }

    @Test
    void rejectsOpenXmlWithOleEmbedding() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                openXml("word/document.xml", "word/embeddings/oleObject1.bin", "ole")
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(controller, "validateFile", file, Set.of(".docx"))
        );

        assertEquals(400, exception.getStatus());
    }

    @Test
    void rejectsOpenXmlWithExternalRelationship() throws Exception {
        String rels = """
                <?xml version="1.0" encoding="UTF-8"?>
                <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="https://example.invalid/a.png" TargetMode="External"/>
                </Relationships>
                """;
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "document.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                openXml("word/document.xml", "word/_rels/document.xml.rels", rels)
        );

        ApiException exception = assertThrows(
                ApiException.class,
                () -> ReflectionTestUtils.invokeMethod(controller, "validateFile", file, Set.of(".docx"))
        );

        assertEquals(400, exception.getStatus());
    }

    @Test
    void userCannotReadAnotherUsersFileMetadata() {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService);
        AuthContext.set(userPrincipal(7));
        when(fileInfoService.getById(55)).thenReturn(fileInfo(55, 100));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 8));

        ApiException exception = assertThrows(ApiException.class, () -> securedController.getById(55));

        assertEquals(403, exception.getStatus());
        assertEquals("cannot access another user's file", exception.getMessage());
    }

    @Test
    void userCannotListAnotherUsersOrderFiles() {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService);
        AuthContext.set(userPrincipal(7));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 8));

        ApiException exception = assertThrows(ApiException.class, () -> securedController.getByOrder(100));

        assertEquals(403, exception.getStatus());
        verify(fileInfoService, never()).getByOrderId(100);
    }

    @Test
    void userCannotUploadToAnotherUsersOrder() {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService);
        AuthContext.set(userPrincipal(7));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 8));

        ApiException exception = assertThrows(
                ApiException.class,
                () -> securedController.uploadFile(null, 100, "document.pdf")
        );

        assertEquals(403, exception.getStatus());
        verify(fileInfoService, never()).add(org.mockito.ArgumentMatchers.any(FileInfo.class));
    }

    @Test
    void userCannotDownloadAnotherUsersFile() {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService);
        AuthContext.set(userPrincipal(7));
        when(fileInfoService.getById(55)).thenReturn(fileInfo(55, 100));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 8));

        ApiException exception = assertThrows(ApiException.class, () -> securedController.downloadFile(55));

        assertEquals(403, exception.getStatus());
    }

    @Test
    void adminCanReadAnyFileMetadata() {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService);
        AuthContext.set(adminPrincipal(1));
        FileInfo fileInfo = fileInfo(55, 100);
        when(fileInfoService.getById(55)).thenReturn(fileInfo);
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 8));

        FileInfo result = securedController.getById(55);

        assertEquals(fileInfo.getId(), result.getId());
        assertEquals(fileInfo.getOrderId(), result.getOrderId());
        assertEquals(fileInfo.getFileName(), result.getFileName());
        assertEquals("/api/file/download/55", result.getFileUrl());
    }

    @Test
    void fileListDoesNotExposeInternalStoragePath() {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService);
        AuthContext.set(userPrincipal(7));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 7));
        when(fileInfoService.getByOrderId(100)).thenReturn(List.of(fileInfo(55, 100, "/files/order_100_secret.pdf")));

        List<FileInfo> result = securedController.getByOrder(100);

        assertEquals(1, result.size());
        assertEquals("/api/file/download/55", result.get(0).getFileUrl());
    }

    @Test
    void adminDeleteRemovesStoredFileAndMetadata(@TempDir Path tempDir) throws Exception {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService, tempDir.toString());
        AuthContext.set(adminPrincipal(1));
        Path stored = tempDir.resolve("stored.pdf");
        Files.write(stored, pdf(1));
        when(fileInfoService.getById(55)).thenReturn(fileInfo(55, 100, "/files/stored.pdf"));
        when(fileInfoService.delete(55)).thenReturn(1);

        int rows = securedController.delete(55);

        assertEquals(1, rows);
        assertEquals(false, Files.exists(stored));
        verify(fileInfoService).delete(55);
    }

    @Test
    void downloadRejectsUnsafeStoredFileUrl() {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService);
        AuthContext.set(adminPrincipal(1));
        when(fileInfoService.getById(55)).thenReturn(fileInfo(55, 100, "/files/../secret.pdf"));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 8));

        ApiException exception = assertThrows(ApiException.class, () -> securedController.downloadFile(55));

        assertEquals(400, exception.getStatus());
        assertEquals("invalid stored file path", exception.getMessage());
    }

    @Test
    void uploadRemovesStoredFileWhenMetadataSaveFails(@TempDir Path tempDir) throws Exception {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService, tempDir.toString());
        AuthContext.set(userPrincipal(7));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 7));
        when(fileInfoService.add(org.mockito.ArgumentMatchers.any(FileInfo.class))).thenReturn(0);
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "notes.txt",
                "text/plain",
                "hello".getBytes(StandardCharsets.UTF_8)
        );

        ApiException exception = assertThrows(ApiException.class, () -> securedController.uploadFile(file, 100, "notes.txt"));

        assertEquals(503, exception.getStatus());
        assertEquals(0, countFiles(tempDir));
    }

    @Test
    void uploadFallsBackToMultipartFilenameWhenPreferredNameBecomesBlank(@TempDir Path tempDir) throws Exception {
        FileInfoService fileInfoService = mock(FileInfoService.class);
        OrderInfoService orderInfoService = mock(OrderInfoService.class);
        FileInfoController securedController = controllerWithServices(fileInfoService, orderInfoService, tempDir.toString());
        AuthContext.set(userPrincipal(7));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 7));
        doAnswer(invocation -> {
            FileInfo fileInfo = invocation.getArgument(0, FileInfo.class);
            assertEquals("notes.txt", fileInfo.getFileName());
            fileInfo.setId(77);
            return 1;
        }).when(fileInfoService).add(any(FileInfo.class));
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "notes.txt",
                "text/plain",
                "hello".getBytes(StandardCharsets.UTF_8)
        );

        var result = securedController.uploadFile(file, 100, "////");

        assertEquals(200, result.get("code"));
        assertEquals("/api/file/download/77", result.get("fileUrl"));
    }

    private FileInfoController controllerWithLimits(int maxEntries,
                                                    long maxEntryBytes,
                                                    long maxTotalBytes,
                                                    int maxPdfPages,
                                                    boolean rejectEncryptedPdf,
                                                    int maxImageWidth,
                                                    int maxImageHeight,
                                                    long maxImagePixels) {
        return new FileInfoController(
                null,
                null,
                "",
                new FileScanService(false, "127.0.0.1", 3310, 1000, true),
                disabledImageModeration(),
                maxEntries,
                maxEntryBytes,
                maxTotalBytes,
                maxPdfPages,
                rejectEncryptedPdf,
                10000,
                64,
                2 * 1024 * 1024,
                20 * 1024 * 1024,
                maxImageWidth,
                maxImageHeight,
                maxImagePixels
        );
    }

    private FileInfoController controllerWithPdfLimits(int maxPdfPages,
                                                       boolean rejectEncryptedPdf,
                                                       int maxPdfObjects,
                                                       int maxPdfPageContentStreams,
                                                       long maxPdfPageContentBytes,
                                                       long maxPdfTotalContentBytes) {
        return new FileInfoController(
                null,
                null,
                "",
                new FileScanService(false, "127.0.0.1", 3310, 1000, true),
                disabledImageModeration(),
                2000,
                20 * 1024 * 1024,
                100 * 1024 * 1024,
                maxPdfPages,
                rejectEncryptedPdf,
                maxPdfObjects,
                maxPdfPageContentStreams,
                maxPdfPageContentBytes,
                maxPdfTotalContentBytes,
                10000,
                10000,
                40_000_000
        );
    }

    private FileInfoController controllerWithServices(FileInfoService fileInfoService, OrderInfoService orderInfoService) {
        return controllerWithServices(fileInfoService, orderInfoService, "");
    }

    private FileInfoController controllerWithServices(FileInfoService fileInfoService,
                                                      OrderInfoService orderInfoService,
                                                      String uploadDir) {
        return new FileInfoController(
                fileInfoService,
                orderInfoService,
                uploadDir,
                new FileScanService(false, "127.0.0.1", 3310, 1000, true),
                disabledImageModeration(),
                2000,
                20 * 1024 * 1024,
                100 * 1024 * 1024,
                200,
                true,
                10000,
                64,
                2 * 1024 * 1024,
                20 * 1024 * 1024,
                10000,
                10000,
                40_000_000
        );
    }

    private FileInfoController controllerWithModeration(ImageContentModerationService moderationService) {
        return new FileInfoController(
                null,
                null,
                "",
                new FileScanService(false, "127.0.0.1", 3310, 1000, true),
                moderationService,
                2000,
                20 * 1024 * 1024,
                100 * 1024 * 1024,
                200,
                true,
                10000,
                64,
                2 * 1024 * 1024,
                20 * 1024 * 1024,
                10000,
                10000,
                40_000_000
        );
    }

    private ImageContentModerationService disabledImageModeration() {
        return new ImageContentModerationService(new RestTemplate(), new ObjectMapper(), false, "", "", true);
    }

    private FileInfo fileInfo(Integer id, Integer orderId) {
        return fileInfo(id, orderId, "/files/order_100_document.pdf");
    }

    private FileInfo fileInfo(Integer id, Integer orderId, String fileUrl) {
        FileInfo fileInfo = new FileInfo();
        fileInfo.setId(id);
        fileInfo.setOrderId(orderId);
        fileInfo.setFileName("document.pdf");
        fileInfo.setFileUrl(fileUrl);
        return fileInfo;
    }

    private long countFiles(Path dir) throws Exception {
        try (var files = Files.list(dir)) {
            return files.count();
        }
    }

    private OrderInfo order(Integer id, Integer userId) {
        OrderInfo order = new OrderInfo();
        order.setId(id);
        order.setUserId(userId);
        return order;
    }

    private AuthPrincipal userPrincipal(Integer id) {
        AuthPrincipal principal = new AuthPrincipal();
        principal.setId(id);
        principal.setType("user");
        principal.setSubject("user:" + id);
        return principal;
    }

    private AuthPrincipal adminPrincipal(Integer id) {
        AuthPrincipal principal = new AuthPrincipal();
        principal.setId(id);
        principal.setType("admin");
        principal.setRole("admin");
        principal.setSubject("admin:" + id);
        return principal;
    }

    private byte[] png(int width, int height) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        ImageIO.write(image, "png", output);
        return output.toByteArray();
    }

    private byte[] pdf(int pages) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (PDDocument document = new PDDocument()) {
            for (int i = 0; i < pages; i++) {
                document.addPage(new PDPage());
            }
            document.save(output);
        }
        return output.toByteArray();
    }

    private byte[] pdfWithContentBytes(int contentBytes) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);
            PDStream stream = new PDStream(document);
            try (OutputStream streamOutput = stream.createOutputStream()) {
                streamOutput.write("x".repeat(contentBytes).getBytes(StandardCharsets.US_ASCII));
            }
            page.setContents(stream);
            document.save(output);
        }
        return output.toByteArray();
    }

    private byte[] encryptedPdf() throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (PDDocument document = new PDDocument()) {
            document.addPage(new PDPage());
            StandardProtectionPolicy policy = new StandardProtectionPolicy(
                    "owner-password",
                    "user-password",
                    new AccessPermission()
            );
            policy.setEncryptionKeyLength(128);
            document.protect(policy);
            document.save(output);
        }
        return output.toByteArray();
    }

    private byte[] openXml(String requiredEntry) throws Exception {
        return openXml(requiredEntry, null, 6);
    }

    private byte[] openXml(String requiredEntry, String extraEntry, int requiredEntryBytes) throws Exception {
        return openXml(requiredEntry, extraEntry, "evil", requiredEntryBytes);
    }

    private byte[] openXml(String requiredEntry, String extraEntry, String extraContent) throws Exception {
        return openXml(requiredEntry, extraEntry, extraContent, 8);
    }

    private byte[] openXml(String requiredEntry,
                           String extraEntry,
                           String extraContent,
                           int requiredEntryBytes) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(output)) {
            zip.putNextEntry(new ZipEntry("[Content_Types].xml"));
            zip.write("<Types/>".getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
            zip.putNextEntry(new ZipEntry(requiredEntry));
            zip.write("x".repeat(requiredEntryBytes).getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
            if (extraEntry != null) {
                zip.putNextEntry(new ZipEntry(extraEntry));
                zip.write(extraContent.getBytes(StandardCharsets.UTF_8));
                zip.closeEntry();
            }
        }
        return output.toByteArray();
    }
}
