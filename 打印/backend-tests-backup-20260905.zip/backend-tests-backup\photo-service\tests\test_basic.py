"""
基础测试
"""

import pytest
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health_check():
    """测试健康检查接口"""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"


def test_root():
    """测试根路径"""
    response = client.get("/")
    assert response.status_code == 200
    assert "证件照智能处理系统" in response.text


def test_api_info():
    """测试API信息"""
    response = client.get("/api")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "证件照智能处理API"


def test_gateway_health_check():
    """测试Gateway路径健康检查接口"""
    response = client.get("/api/photo/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"


def test_gateway_metrics_check():
    """测试Gateway路径监控指标"""
    response = client.get("/api/photo/metrics")
    assert response.status_code == 200
    data = response.json()
    assert data["service"] == "photo-service"
    assert "instanceId" in data
    assert data["requestsTotal"] >= 1


def test_prometheus_metrics_check():
    """测试Prometheus文本指标"""
    response = client.get("/metrics")
    assert response.status_code == 200
    assert "photo_service_requests_total" in response.text


def test_docs_accessible():
    """测试Swagger文档是否可访问"""
    response = client.get("/docs")
    assert response.status_code == 200


def test_change_background_invalid_file():
    """测试换底色接口 - 无效文件"""
    # 发送非图片文件
    response = client.post(
        "/api/v1/change-background",
        files={"image": ("test.txt", b"not an image", "text/plain")}
    )
    assert response.status_code == 400


def test_gateway_change_background_invalid_file():
    """测试Gateway兼容换底色接口 - 无效文件"""
    response = client.post(
        "/api/photo/change-background",
        files={"image": ("test.txt", b"not an image", "text/plain")}
    )
    assert response.status_code == 400


def test_generate_id_photo_invalid_size():
    """测试生成证件照接口 - 无效尺寸"""
    # 创建一个简单的测试图像
    from PIL import Image
    import io
    
    # 创建测试图像
    img = Image.new('RGB', (100, 100), color='red')
    img_bytes = io.BytesIO()
    img.save(img_bytes, format='JPEG')
    img_bytes.seek(0)
    
    response = client.post(
        "/api/v1/generate-id-photo",
        files={"image": ("test.jpg", img_bytes, "image/jpeg")},
        data={"size": "无效尺寸"}
    )
    assert response.status_code == 400


def test_gateway_generate_id_photo_invalid_size():
    """测试Gateway兼容生成证件照接口 - 无效尺寸"""
    from PIL import Image
    import io

    img = Image.new('RGB', (100, 100), color='red')
    img_bytes = io.BytesIO()
    img.save(img_bytes, format='JPEG')
    img_bytes.seek(0)

    response = client.post(
        "/api/photo/generate-id-photo",
        files={"image": ("test.jpg", img_bytes, "image/jpeg")},
        data={"size": "无效尺寸"}
    )
    assert response.status_code == 400
