package com.example.printshop.controller;

import com.example.printshop.common.ApiException;
import com.example.printshop.entity.OrderInfo;
import com.example.printshop.security.AuthContext;
import com.example.printshop.security.AuthPrincipal;
import com.example.printshop.service.OrderInfoService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class OrderInfoControllerTest {
    private OrderInfoService orderInfoService;
    private OrderInfoController controller;

    @BeforeEach
    void setUp() {
        orderInfoService = mock(OrderInfoService.class);
        controller = new OrderInfoController();
        ReflectionTestUtils.setField(controller, "orderInfoService", orderInfoService);
    }

    @AfterEach
    void tearDown() {
        AuthContext.clear();
    }

    @Test
    void userCannotReadAnotherUsersOrder() {
        AuthContext.set(userPrincipal(7));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 8, 0));

        ApiException exception = assertThrows(ApiException.class, () -> controller.getOrderById(100));

        assertEquals(403, exception.getStatus());
        assertEquals("cannot access another user's order", exception.getMessage());
    }

    @Test
    void userCanReadOwnOrder() {
        AuthContext.set(userPrincipal(7));
        OrderInfo order = order(100, 7, 0);
        when(orderInfoService.getOrderById(100)).thenReturn(order);

        OrderInfo result = controller.getOrderById(100);

        assertEquals(order, result);
    }

    @Test
    void userCannotListAnotherUsersOrders() {
        AuthContext.set(userPrincipal(7));

        ApiException exception = assertThrows(ApiException.class, () -> controller.getOrdersByUserId(8));

        assertEquals(403, exception.getStatus());
        assertEquals("cannot access another user's orders", exception.getMessage());
        verify(orderInfoService, never()).getOrdersByUserId(8);
    }

    @Test
    void userCanListOwnOrders() {
        AuthContext.set(userPrincipal(7));
        List<OrderInfo> orders = List.of(order(100, 7, 0));
        when(orderInfoService.getOrdersByUserId(7)).thenReturn(orders);

        List<OrderInfo> result = controller.getOrdersByUserId(7);

        assertEquals(orders, result);
    }

    @Test
    void userCannotCancelAnotherUsersOrder() {
        AuthContext.set(userPrincipal(7));
        when(orderInfoService.getOrderById(100)).thenReturn(order(100, 8, 0));

        ApiException exception = assertThrows(ApiException.class, () -> controller.cancelOrder(100));

        assertEquals(403, exception.getStatus());
        verify(orderInfoService, never()).updateOrderStatus(100, 4, null);
    }

    @Test
    void adminCanReadAnyOrder() {
        AuthContext.set(adminPrincipal(1));
        OrderInfo order = order(100, 8, 0);
        when(orderInfoService.getOrderById(100)).thenReturn(order);

        OrderInfo result = controller.getOrderById(100);

        assertEquals(order, result);
    }

    @Test
    void userCreateOrderUsesAuthenticatedUserAndPendingStatus() {
        AuthContext.set(userPrincipal(7));
        OrderInfo order = order(null, 99, 3);
        when(orderInfoService.generateQueueNumber()).thenReturn("Q20260705001");
        when(orderInfoService.generateFetchCode()).thenReturn("123456");
        doAnswer(invocation -> {
            invocation.getArgument(0, OrderInfo.class).setId(101);
            return 1;
        }).when(orderInfoService).createOrder(order);

        Integer orderId = controller.createOrder(order);

        assertEquals(101, orderId);
        assertEquals(7, order.getUserId());
        assertEquals(0, order.getOrderStatus());
        assertEquals("Q20260705001", order.getQueueNumber());
        assertEquals("123456", order.getFetchCode());
        verify(orderInfoService).createOrder(order);
    }

    private OrderInfo order(Integer id, Integer userId, Integer status) {
        OrderInfo order = new OrderInfo();
        order.setId(id);
        order.setUserId(userId);
        order.setOrderStatus(status);
        return order;
    }

    private AuthPrincipal userPrincipal(Integer id) {
        AuthPrincipal principal = new AuthPrincipal();
        principal.setId(id);
        principal.setType("user");
        principal.setSubject("user:" + id);
        return principal;
    }

    private AuthPrincipal adminPrincipal(Integer id) {
        AuthPrincipal principal = new AuthPrincipal();
        principal.setId(id);
        principal.setType("admin");
        principal.setRole("admin");
        principal.setSubject("admin:" + id);
        return principal;
    }
}
