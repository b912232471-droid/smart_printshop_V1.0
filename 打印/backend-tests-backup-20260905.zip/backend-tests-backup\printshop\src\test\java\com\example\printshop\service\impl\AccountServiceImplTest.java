package com.example.printshop.service.impl;

import com.example.printshop.common.ApiException;
import com.example.printshop.entity.Account;
import com.example.printshop.mapper.AccountMapper;
import com.example.printshop.security.FieldCryptoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AccountServiceImplTest {
    private AccountMapper mapper;
    private BCryptPasswordEncoder encoder;
    private FieldCryptoService cryptoService;
    private AccountServiceImpl service;

    @BeforeEach
    void setUp() {
        mapper = mock(AccountMapper.class);
        encoder = new BCryptPasswordEncoder();
        cryptoService = new FieldCryptoService("test-field-encryption-key-1234567890");
        service = new AccountServiceImpl(mapper, encoder, cryptoService);
    }

    @Test
    void registersUserWithBcryptPasswordAndUserRole() {
        doAnswer(invocation -> {
            Account account = invocation.getArgument(0, Account.class);
            account.setId(12);
            return 1;
        }).when(mapper).insertUser(any(Account.class));
        when(mapper.selectById(12)).thenAnswer(invocation -> {
            Account account = new Account();
            account.setId(12);
            account.setUsername("123456@qq.com");
            account.setAccountType("user");
            account.setRole("user");
            account.setStatus(1);
            return account;
        });

        Account result = service.registerUser("123456@qq.com", "Password1", "小明");

        assertEquals(12, result.getId());
        verify(mapper).insertUser(org.mockito.ArgumentMatchers.argThat(account ->
                "user".equals(account.getAccountType())
                        && "user".equals(account.getRole())
                        && "123456@qq.com".equals(account.getUsername())
                        && cryptoService.blindIndex("123456@qq.com").equals(account.getEmailHash())
                        && encoder.matches("Password1", account.getPasswordHash())));
    }

    @Test
    void authenticatesOnlyRequestedAccountType() {
        Account account = account("123456@qq.com", "Password1", "user", 1);
        when(mapper.selectByEmailHash(cryptoService.blindIndex("123456@qq.com"))).thenReturn(account);

        Account result = service.authenticate("123456@qq.com", "Password1", "user");

        assertEquals(account.getId(), result.getId());
        assertNull(result.getPasswordHash());
        verify(mapper).updateLastLoginTime(account.getId());
        assertNull(service.authenticate("123456@qq.com", "Password1", "admin"));
    }

    @Test
    void rejectsWeakPasswordAndDisabledAccount() {
        assertThrows(ApiException.class, () -> service.registerUser("123456@qq.com", "12345678", null));
        when(mapper.selectByEmailHash(cryptoService.blindIndex("123456@qq.com")))
                .thenReturn(account("123456@qq.com", "Password1", "user", 0));
        ApiException exception = assertThrows(ApiException.class,
                () -> service.authenticate("123456@qq.com", "Password1", "user"));
        assertEquals(403, exception.getStatus());
    }

    @Test
    void superAdminResetStoresBcryptPassword() {
        Account account = account("legacy_user_7", "OldPass9!", "user", 1);
        when(mapper.selectById(12)).thenReturn(account);

        service.resetPassword(12, "NewPass9!");

        verify(mapper).updatePassword(org.mockito.ArgumentMatchers.eq(12),
                org.mockito.ArgumentMatchers.argThat(hash -> encoder.matches("NewPass9!", hash)));
    }

    private Account account(String username, String password, String type, int status) {
        Account account = new Account();
        account.setId(12);
        account.setUsername(username);
        account.setPasswordHash(encoder.encode(password));
        account.setAccountType(type);
        account.setRole("user");
        account.setStatus(status);
        return account;
    }
}
