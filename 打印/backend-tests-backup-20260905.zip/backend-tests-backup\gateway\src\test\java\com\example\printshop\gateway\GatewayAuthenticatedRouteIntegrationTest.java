package com.example.printshop.gateway;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;
import reactor.netty.DisposableServer;
import reactor.netty.http.server.HttpServer;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
        "gateway.security.auth.enabled=true",
        "gateway.security.rate-limit.enabled=false",
        "gateway.security.request-log.enabled=false",
        "spring.cloud.nacos.discovery.enabled=false"
})
@AutoConfigureWebTestClient(timeout = "PT10S")
class GatewayAuthenticatedRouteIntegrationTest {
    private static final String JWT_SECRET = "gateway-auth-integration-secret-with-more-than-32-characters";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final MockBackend PRINT_SERVICE = MockBackend.start();
    private static final MockBackend PHOTO_SERVICE = MockBackend.start();

    @Autowired
    private WebTestClient webTestClient;

    @DynamicPropertySource
    static void gatewayProperties(DynamicPropertyRegistry registry) {
        registry.add("PRINT_SERVICE_URI", PRINT_SERVICE::baseUrl);
        registry.add("PHOTO_SERVICE_URI", PHOTO_SERVICE::baseUrl);
        registry.add("gateway.security.auth.jwt-secret", () -> JWT_SECRET);
    }

    @BeforeEach
    void clearRecordedRequests() {
        PRINT_SERVICE.clear();
        PHOTO_SERVICE.clear();
    }

    @AfterAll
    static void stopBackends() {
        PRINT_SERVICE.stop();
        PHOTO_SERVICE.stop();
    }

    @Test
    void protectedRouteWithoutBearerTokenIsRejectedBeforeBackend() throws Exception {
        webTestClient.get()
                .uri("/api/print/order/123")
                .exchange()
                .expectStatus().isUnauthorized()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.code").isEqualTo(401)
                .jsonPath("$.message").isEqualTo("unauthorized");

        PRINT_SERVICE.assertNoRequest();
    }

    @Test
    void protectedRouteWithValidBearerTokenForwardsToBackend() throws Exception {
        webTestClient.get()
                .uri("/api/print/order/123")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + validUserToken(9))
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.path").isEqualTo("/api/order/123")
                .jsonPath("$.method").isEqualTo("GET");

        RecordedRequest request = PRINT_SERVICE.take();
        assertEquals("GET", request.method());
        assertEquals("/api/order/123", request.uri());
        assertNotNull(request.authorization());
    }

    @Test
    void publicAccountLoginRouteStillForwardsWithoutBearerToken() throws Exception {
        webTestClient.post()
                .uri("/api/print/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"username\":\"student1\",\"password\":\"Password1\"}")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.path").isEqualTo("/api/auth/login")
                .jsonPath("$.method").isEqualTo("POST");

        RecordedRequest request = PRINT_SERVICE.take();
        assertEquals("POST", request.method());
        assertEquals("/api/auth/login", request.uri());
        assertNull(request.authorization());
    }

    @Test
    void futureServiceRouteWithoutBearerTokenIsRejectedBeforeBackend() throws Exception {
        webTestClient.post()
                .uri("/api/photo/generate-id-photo")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"fileId\":1}")
                .exchange()
                .expectStatus().isUnauthorized()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.code").isEqualTo(401)
                .jsonPath("$.message").isEqualTo("unauthorized");

        PHOTO_SERVICE.assertNoRequest();
    }

    @Test
    void futureServiceRouteWithValidBearerTokenForwardsToBackend() throws Exception {
        webTestClient.post()
                .uri("/api/photo/generate-id-photo")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + validUserToken(9))
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"fileId\":1}")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.path").isEqualTo("/api/photo/generate-id-photo")
                .jsonPath("$.method").isEqualTo("POST");

        RecordedRequest request = PHOTO_SERVICE.take();
        assertEquals("POST", request.method());
        assertEquals("/api/photo/generate-id-photo", request.uri());
        assertNotNull(request.authorization());
    }

    private String validUserToken(int userId) throws Exception {
        long now = Instant.now().getEpochSecond();
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("alg", "HS256");
        header.put("typ", "JWT");
        Map<String, Object> claims = new LinkedHashMap<>();
        claims.put("typ", "JWT");
        claims.put("type", "user");
        claims.put("id", userId);
        claims.put("sub", "user:" + userId);
        claims.put("role", "user");
        claims.put("username", "user-" + userId);
        claims.put("iat", now);
        claims.put("exp", now + 3600);
        claims.put("jti", UUID.randomUUID().toString());

        String headerPart = base64Url(OBJECT_MAPPER.writeValueAsBytes(header));
        String payloadPart = base64Url(OBJECT_MAPPER.writeValueAsBytes(claims));
        String signed = headerPart + "." + payloadPart;
        return signed + "." + base64Url(hmac(signed.getBytes(StandardCharsets.UTF_8)));
    }

    private byte[] hmac(byte[] data) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(JWT_SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return mac.doFinal(data);
    }

    private String base64Url(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private record RecordedRequest(String method, String uri, String authorization) {
    }

    private static class MockBackend {
        private final DisposableServer server;
        private final LinkedBlockingQueue<RecordedRequest> requests;

        private MockBackend(DisposableServer server, LinkedBlockingQueue<RecordedRequest> requests) {
            this.server = server;
            this.requests = requests;
        }

        static MockBackend start() {
            LinkedBlockingQueue<RecordedRequest> requests = new LinkedBlockingQueue<>();
            DisposableServer server = HttpServer.create()
                    .host("127.0.0.1")
                    .port(0)
                    .handle((request, response) -> {
                        String uri = request.uri();
                        String method = request.method().name();
                        String authorization = request.requestHeaders().get(HttpHeaders.AUTHORIZATION);
                        requests.add(new RecordedRequest(method, uri, authorization));
                        String body = "{\"method\":\"" + method + "\",\"path\":\"" + uri + "\"}";
                        return response.status(200)
                                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .sendString(Mono.just(body));
                    })
                    .bindNow(Duration.ofSeconds(5));
            return new MockBackend(server, requests);
        }

        String baseUrl() {
            return "http://127.0.0.1:" + server.port();
        }

        RecordedRequest take() throws InterruptedException {
            RecordedRequest request = requests.poll(5, TimeUnit.SECONDS);
            assertNotNull(request, "backend did not receive a request");
            return request;
        }

        void assertNoRequest() throws InterruptedException {
            RecordedRequest request = requests.poll(300, TimeUnit.MILLISECONDS);
            assertNull(request, "backend should not receive rejected request");
        }

        void clear() {
            requests.clear();
        }

        void stop() {
            server.disposeNow();
        }
    }
}
