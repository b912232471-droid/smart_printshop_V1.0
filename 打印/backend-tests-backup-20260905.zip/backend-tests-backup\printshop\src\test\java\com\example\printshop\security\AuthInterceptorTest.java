package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class AuthInterceptorTest {
    private final JwtService jwtService = mock(JwtService.class);
    private final AuthInterceptor interceptor = new AuthInterceptor(jwtService);

    @AfterEach
    void clearContext() {
        AuthContext.clear();
    }

    @Test
    void allowsPublicActiveStoreQueryWithoutToken() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/store/active");

        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
        verifyNoInteractions(jwtService);
    }

    @Test
    void rejectsFullStoreListWithoutToken() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/store/");

        ApiException exception = assertThrows(
                ApiException.class,
                () -> interceptor.preHandle(request, new MockHttpServletResponse(), new Object())
        );

        assertEquals(401, exception.getStatus());
    }

    @Test
    void allowsPostAccountLoginWithoutToken() {
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/auth/login");

        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
        verifyNoInteractions(jwtService);
    }

    @Test
    void rejectsGetAccountLoginWithoutToken() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/auth/login");

        ApiException exception = assertThrows(
                ApiException.class,
                () -> interceptor.preHandle(request, new MockHttpServletResponse(), new Object())
        );

        assertEquals(401, exception.getStatus());
    }

    @Test
    void clearsStalePrincipalAtStartOfPublicRequest() {
        AuthPrincipal stale = new AuthPrincipal();
        stale.setId(99);
        stale.setType("admin");
        AuthContext.set(stale);
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/store/active");

        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));

        assertThrows(ApiException.class, AuthContext::get);
    }

    @Test
    void rejectsProtectedRequestWithoutBearerToken() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/order/1");

        ApiException exception = assertThrows(
                ApiException.class,
                () -> interceptor.preHandle(request, new MockHttpServletResponse(), new Object())
        );

        assertEquals(401, exception.getStatus());
        assertEquals("missing bearer token", exception.getMessage());
    }

    @Test
    void parsesBearerTokenAndClearsContextAfterCompletion() {
        AuthPrincipal principal = new AuthPrincipal();
        principal.setId(3);
        principal.setType("user");
        when(jwtService.parse("token-1")).thenReturn(principal);
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/order/1");
        request.addHeader("Authorization", "Bearer token-1");

        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
        assertSame(principal, AuthContext.get());

        interceptor.afterCompletion(request, new MockHttpServletResponse(), new Object(), null);

        assertThrows(ApiException.class, AuthContext::get);
    }
}
