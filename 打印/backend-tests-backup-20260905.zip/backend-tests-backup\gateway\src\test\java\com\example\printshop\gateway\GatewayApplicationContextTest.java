package com.example.printshop.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.timelimiter.TimeLimiterRegistry;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
        "gateway.security.rate-limit.enabled=false",
        "gateway.security.request-log.enabled=false",
        "spring.cloud.nacos.discovery.enabled=false",
        "GATEWAY_CB_SLIDING_WINDOW_SIZE=20",
        "GATEWAY_CB_MINIMUM_CALLS=10",
        "GATEWAY_CB_FAILURE_RATE_THRESHOLD=50",
        "GATEWAY_CB_HALF_OPEN_CALLS=3",
        "GATEWAY_CB_TIMEOUT=10s",
        "GATEWAY_PHOTO_CB_SLIDING_WINDOW_SIZE=31",
        "GATEWAY_PHOTO_CB_MINIMUM_CALLS=11",
        "GATEWAY_PHOTO_CB_FAILURE_RATE_THRESHOLD=42",
        "GATEWAY_PHOTO_CB_HALF_OPEN_CALLS=5",
        "GATEWAY_PHOTO_CB_TIMEOUT=17s"
})
@AutoConfigureWebTestClient
class GatewayApplicationContextTest {
    @Autowired
    private RouteLocator routeLocator;

    @Autowired
    private WebTestClient webTestClient;

    @Autowired
    private CircuitBreakerRegistry circuitBreakerRegistry;

    @Autowired
    private TimeLimiterRegistry timeLimiterRegistry;

    @Test
    void loadsConfiguredServiceRoutesWithCircuitBreakers() {
        List<String> routeIds = routeLocator.getRoutes()
                .map(Route::getId)
                .collectList()
                .block(Duration.ofSeconds(5));

        assertTrue(routeIds.contains("print-service-plan-prefix"));
        assertTrue(routeIds.contains("print-service-compat"));
        assertTrue(routeIds.contains("photo-service"));
        assertTrue(routeIds.contains("schedule-service"));
        assertTrue(routeIds.contains("chat-service"));
    }

    @Test
    void exposesPrintServiceFallbackEndpoint() {
        webTestClient.get()
                .uri("/fallback/print-service")
                .exchange()
                .expectStatus().isEqualTo(503)
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.code").isEqualTo(503)
                .jsonPath("$.message").isEqualTo("print service unavailable");
    }

    @Test
    void supportsServiceSpecificCircuitBreakerOverrides() {
        CircuitBreakerConfig printConfig = circuitBreakerRegistry.circuitBreaker("printServiceCircuitBreaker").getCircuitBreakerConfig();
        CircuitBreakerConfig photoConfig = circuitBreakerRegistry.circuitBreaker("photoServiceCircuitBreaker").getCircuitBreakerConfig();

        assertEquals(20, printConfig.getSlidingWindowSize());
        assertEquals(10, printConfig.getMinimumNumberOfCalls());
        assertEquals(50.0f, printConfig.getFailureRateThreshold(), 0.001f);
        assertEquals(3, printConfig.getPermittedNumberOfCallsInHalfOpenState());
        assertEquals(Duration.ofSeconds(10), timeLimiterRegistry.timeLimiter("printServiceCircuitBreaker").getTimeLimiterConfig().getTimeoutDuration());

        assertEquals(31, photoConfig.getSlidingWindowSize());
        assertEquals(11, photoConfig.getMinimumNumberOfCalls());
        assertEquals(42.0f, photoConfig.getFailureRateThreshold(), 0.001f);
        assertEquals(5, photoConfig.getPermittedNumberOfCallsInHalfOpenState());
        assertEquals(Duration.ofSeconds(17), timeLimiterRegistry.timeLimiter("photoServiceCircuitBreaker").getTimeLimiterConfig().getTimeoutDuration());
    }

    @Test
    void exposesFutureServiceFallbackEndpoints() {
        assertFallback("/fallback/photo-service", "photo service unavailable");
        assertFallback("/fallback/schedule-service", "schedule service unavailable");
        assertFallback("/fallback/chat-service", "chat service unavailable");
    }

    private void assertFallback(String uri, String message) {
        webTestClient.get()
                .uri(uri)
                .exchange()
                .expectStatus().isEqualTo(503)
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.code").isEqualTo(503)
                .jsonPath("$.message").isEqualTo(message);
    }
}
