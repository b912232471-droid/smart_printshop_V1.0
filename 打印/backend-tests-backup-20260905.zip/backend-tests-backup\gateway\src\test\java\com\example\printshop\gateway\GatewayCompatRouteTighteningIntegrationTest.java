package com.example.printshop.gateway;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;
import reactor.netty.DisposableServer;
import reactor.netty.http.server.HttpServer;

import java.time.Duration;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
        "gateway.security.auth.enabled=false",
        "gateway.security.rate-limit.enabled=false",
        "gateway.security.request-log.enabled=false",
        "spring.cloud.nacos.discovery.enabled=false",
        "GATEWAY_PRINT_COMPAT_PATHS=/api/public-files/**"
})
@AutoConfigureWebTestClient(timeout = "PT10S")
class GatewayCompatRouteTighteningIntegrationTest {
    private static final MockBackend PRINT_SERVICE = MockBackend.start();

    @Autowired
    private WebTestClient webTestClient;

    @DynamicPropertySource
    static void gatewayProperties(DynamicPropertyRegistry registry) {
        registry.add("PRINT_SERVICE_URI", PRINT_SERVICE::baseUrl);
    }

    @BeforeEach
    void clearRecordedRequests() {
        PRINT_SERVICE.clear();
    }

    @AfterAll
    static void stopBackends() {
        PRINT_SERVICE.stop();
    }

    @Test
    void compatRouteCanBeLimitedToPublicFilePaths() throws Exception {
        webTestClient.get()
                .uri("/api/public-files/stores/store.png")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.path").isEqualTo("/api/public-files/stores/store.png")
                .jsonPath("$.method").isEqualTo("GET");

        RecordedRequest request = PRINT_SERVICE.take();
        assertEquals("GET", request.method());
        assertEquals("/api/public-files/stores/store.png", request.uri());
    }

    @Test
    void tightenedCompatRouteDoesNotForwardLegacyPrintApiPaths() throws Exception {
        webTestClient.post()
                .uri("/api/order")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"id\":1}")
                .exchange()
                .expectStatus().isNotFound();

        assertNull(PRINT_SERVICE.poll(), "legacy /api/order should not reach print-service");
    }

    private record RecordedRequest(String method, String uri) {
    }

    private static class MockBackend {
        private final DisposableServer server;
        private final LinkedBlockingQueue<RecordedRequest> requests;

        private MockBackend(DisposableServer server, LinkedBlockingQueue<RecordedRequest> requests) {
            this.server = server;
            this.requests = requests;
        }

        static MockBackend start() {
            LinkedBlockingQueue<RecordedRequest> requests = new LinkedBlockingQueue<>();
            DisposableServer server = HttpServer.create()
                    .host("127.0.0.1")
                    .port(0)
                    .handle((request, response) -> {
                        String uri = request.uri();
                        String method = request.method().name();
                        requests.add(new RecordedRequest(method, uri));
                        String body = "{\"method\":\"" + method + "\",\"path\":\"" + uri + "\"}";
                        return response.status(200)
                                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .sendString(Mono.just(body));
                    })
                    .bindNow(Duration.ofSeconds(5));
            return new MockBackend(server, requests);
        }

        String baseUrl() {
            return "http://127.0.0.1:" + server.port();
        }

        RecordedRequest take() throws InterruptedException {
            RecordedRequest request = requests.poll(5, TimeUnit.SECONDS);
            assertNotNull(request, "backend did not receive a request");
            return request;
        }

        RecordedRequest poll() throws InterruptedException {
            return requests.poll(300, TimeUnit.MILLISECONDS);
        }

        void clear() {
            requests.clear();
        }

        void stop() {
            server.disposeNow();
        }
    }
}
