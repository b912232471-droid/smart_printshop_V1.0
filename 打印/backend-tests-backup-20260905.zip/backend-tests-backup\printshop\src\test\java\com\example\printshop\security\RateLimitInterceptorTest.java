package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RateLimitInterceptorTest {
    private final Clock clock = Clock.fixed(Instant.parse("2026-07-04T12:00:00Z"), ZoneOffset.UTC);

    @Test
    void rejectsRequestsAfterLimitIsExceeded() {
        RateLimitInterceptor interceptor = new RateLimitInterceptor(true, 2, 60, clock, null);
        MockHttpServletRequest request = request("GET", "/api/order/1", "10.0.0.1");

        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
        ApiException exception = assertThrows(
                ApiException.class,
                () -> interceptor.preHandle(request, new MockHttpServletResponse(), new Object())
        );

        assertEquals(429, exception.getStatus());
    }

    @Test
    void tracksRouteGroupsSeparately() {
        RateLimitInterceptor interceptor = new RateLimitInterceptor(true, 1, 60, clock, null);

        assertTrue(interceptor.preHandle(request("GET", "/api/order/1", "10.0.0.1"), new MockHttpServletResponse(), new Object()));
        assertTrue(interceptor.preHandle(request("GET", "/api/store/", "10.0.0.1"), new MockHttpServletResponse(), new Object()));
    }

    @Test
    void disabledLimiterAllowsRequests() {
        RateLimitInterceptor interceptor = new RateLimitInterceptor(false, 1, 60, clock, null);
        MockHttpServletRequest request = request("GET", "/api/order/1", "10.0.0.1");

        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
        assertTrue(interceptor.preHandle(request, new MockHttpServletResponse(), new Object()));
    }

    @Test
    void clearsStaleAuthenticationContext() {
        RateLimitInterceptor interceptor = new RateLimitInterceptor(true, 10, 60, clock, null);
        AuthPrincipal stale = new AuthPrincipal();
        stale.setId(1);
        stale.setType("admin");
        AuthContext.set(stale);

        assertTrue(interceptor.preHandle(request("GET", "/api/store/", "10.0.0.1"), new MockHttpServletResponse(), new Object()));

        assertThrows(ApiException.class, AuthContext::get);
    }

    @Test
    void ignoresForwardedForHeaderByDefault() {
        RateLimitInterceptor interceptor = new RateLimitInterceptor(true, 1, 60, clock, null);

        assertTrue(interceptor.preHandle(
                requestWithRemoteAndForwarded("GET", "/api/order/1", "10.0.0.1", "10.0.0.2"),
                new MockHttpServletResponse(),
                new Object()
        ));
        ApiException exception = assertThrows(
                ApiException.class,
                () -> interceptor.preHandle(
                        requestWithRemoteAndForwarded("GET", "/api/order/1", "10.0.0.1", "10.0.0.3"),
                        new MockHttpServletResponse(),
                        new Object()
                )
        );

        assertEquals(429, exception.getStatus());
    }

    private MockHttpServletRequest request(String method, String path, String ip) {
        return requestWithRemoteAndForwarded(method, path, ip, "203.0.113.1");
    }

    private MockHttpServletRequest requestWithRemoteAndForwarded(String method, String path, String remoteIp, String forwardedIp) {
        MockHttpServletRequest request = new MockHttpServletRequest(method, path);
        request.addHeader("X-Forwarded-For", forwardedIp + ", 127.0.0.1");
        request.setRemoteAddr(remoteIp);
        return request;
    }
}
