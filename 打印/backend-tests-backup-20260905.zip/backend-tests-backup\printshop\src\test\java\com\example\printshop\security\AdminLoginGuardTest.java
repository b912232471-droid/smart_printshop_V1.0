package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class AdminLoginGuardTest {
    private final AdminLoginGuard guard = new AdminLoginGuard(
            2,
            900,
            900,
            Clock.fixed(Instant.parse("2026-07-04T12:00:00Z"), ZoneOffset.UTC)
    );

    @Test
    void locksSameUsernameAndIpAfterTooManyFailures() {
        MockHttpServletRequest request = request("10.0.0.1");

        guard.recordFailure("admin", request);
        guard.checkAllowed("admin", request);
        guard.recordFailure("admin", request);

        ApiException exception = assertThrows(ApiException.class, () -> guard.checkAllowed("admin", request));

        assertEquals(429, exception.getStatus());
    }

    @Test
    void successClearsFailureCounter() {
        MockHttpServletRequest request = request("10.0.0.1");

        guard.recordFailure("admin", request);
        guard.recordSuccess("admin", request);
        guard.checkAllowed("admin", request);
        guard.recordFailure("admin", request);
        guard.checkAllowed("admin", request);
    }

    @Test
    void tracksDifferentClientIpsSeparately() {
        MockHttpServletRequest first = request("10.0.0.1");
        MockHttpServletRequest second = request("10.0.0.2");

        guard.recordFailure("admin", first);
        guard.recordFailure("admin", first);

        guard.checkAllowed("admin", second);
    }

    @Test
    void ignoresForwardedForHeaderByDefault() {
        MockHttpServletRequest request = request("10.0.0.1");
        request.addHeader("X-Forwarded-For", "10.0.0.2");

        guard.recordFailure("admin", request);
        guard.recordFailure("admin", request);

        ApiException exception = assertThrows(ApiException.class, () -> guard.checkAllowed("admin", request));

        assertEquals(429, exception.getStatus());
    }

    @Test
    void sendsSecurityAlertWhenLoginIsLocked() {
        RecordingSecurityAlertService alertService = new RecordingSecurityAlertService();
        AdminLoginGuard alertingGuard = new AdminLoginGuard(
                2,
                900,
                900,
                Clock.fixed(Instant.parse("2026-07-04T12:00:00Z"), ZoneOffset.UTC),
                new RequestIpResolver(false),
                alertService
        );
        MockHttpServletRequest request = request("10.0.0.1");

        alertingGuard.recordFailure("admin", request);
        alertingGuard.recordFailure("admin", request);

        assertEquals(1, alertService.alerts);
    }

    private MockHttpServletRequest request(String ip) {
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/admin/login");
        request.addHeader("X-Forwarded-For", "203.0.113.1, 127.0.0.1");
        request.setRemoteAddr(ip);
        return request;
    }

    private static class RecordingSecurityAlertService extends SecurityAlertService {
        private int alerts;

        RecordingSecurityAlertService() {
            super(false, "", null);
        }

        @Override
        public void adminLoginLocked(String username, String clientIp, int failures, long lockSeconds) {
            alerts++;
        }
    }
}
