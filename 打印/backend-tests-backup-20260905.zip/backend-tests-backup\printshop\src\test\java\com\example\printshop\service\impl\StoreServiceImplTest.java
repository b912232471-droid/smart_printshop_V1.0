package com.example.printshop.service.impl;

import com.example.printshop.common.ApiException;
import com.example.printshop.entity.Store;
import com.example.printshop.mapper.StoreMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class StoreServiceImplTest {
    private StoreMapper mapper;
    private StoreServiceImpl service;

    @BeforeEach
    void setUp() {
        mapper = mock(StoreMapper.class);
        service = new StoreServiceImpl();
        ReflectionTestUtils.setField(service, "mapper", mapper);
    }

    @Test
    void addDefaultsStatusSortAndImageUrl() {
        Store store = validStore();
        store.setStatus(null);
        store.setSortOrder(null);
        store.setImageUrl(null);
        when(mapper.insert(store)).thenReturn(1);

        int rows = service.add(store);

        assertEquals(1, rows);
        assertEquals(1, store.getStatus());
        assertEquals(0, store.getSortOrder());
        assertEquals("/images/store-default.jpg", store.getImageUrl());
    }

    @Test
    void addRejectsActiveStoreWithoutLatitude() {
        Store store = validStore();
        store.setLatitude(null);

        ApiException exception = assertThrows(ApiException.class, () -> service.add(store));

        assertEquals(400, exception.getStatus());
        assertEquals("门店纬度不合法", exception.getMessage());
    }

    @Test
    void addAllowsClosedStoreWithoutCoordinates() {
        Store store = validStore();
        store.setStatus(0);
        store.setLatitude(null);
        store.setLongitude(null);
        when(mapper.insert(store)).thenReturn(1);

        int rows = service.add(store);

        assertEquals(1, rows);
    }

    @Test
    void addRejectsInvalidStatus() {
        Store store = validStore();
        store.setStatus(9);

        ApiException exception = assertThrows(ApiException.class, () -> service.add(store));

        assertEquals(400, exception.getStatus());
        assertEquals("非法门店状态", exception.getMessage());
    }

    @Test
    void addRejectsUnsafeImageUrl() {
        Store store = validStore();
        store.setImageUrl("javascript:alert(1)");

        ApiException exception = assertThrows(ApiException.class, () -> service.add(store));

        assertEquals(400, exception.getStatus());
        assertEquals("门店图片地址不合法", exception.getMessage());
    }

    @Test
    void addRejectsStoreImagePathTraversal() {
        Store store = validStore();
        store.setImageUrl("/api/public-files/stores/../secret.png");

        ApiException exception = assertThrows(ApiException.class, () -> service.add(store));

        assertEquals(400, exception.getStatus());
        assertEquals("门店图片地址不合法", exception.getMessage());
    }

    @Test
    void updateRequiresId() {
        Store store = validStore();

        ApiException exception = assertThrows(ApiException.class, () -> service.update(store));

        assertEquals(400, exception.getStatus());
        assertEquals("门店ID不能为空", exception.getMessage());
    }

    private Store validStore() {
        Store store = new Store();
        store.setName("主店");
        store.setShortName("主店");
        store.setDeviceCode("printer-001");
        store.setAddress("校内");
        store.setImageUrl("/api/public-files/stores/store.png");
        store.setLatitude(22.8240);
        store.setLongitude(108.3662);
        store.setPhone("4007781811");
        store.setHours("09:00-21:00");
        store.setServices("打印");
        store.setStatus(1);
        store.setSortOrder(1);
        return store;
    }
}
