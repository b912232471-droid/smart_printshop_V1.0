package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

class ImageContentModerationServiceTest {
    private static final String ENDPOINT = "https://moderation.example.test/check";

    @Test
    void disabledModerationAllowsImageWithoutCallingEndpoint() {
        RestTemplate restTemplate = new RestTemplate();
        MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();
        ImageContentModerationService service = service(restTemplate, false, "", "", true);

        assertDoesNotThrow(() -> service.moderate(image()));
        server.verify();
    }

    @Test
    void passResponseAllowsImageAndSendsBearerToken() {
        RestTemplate restTemplate = new RestTemplate();
        MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();
        server.expect(requestTo(ENDPOINT))
                .andExpect(method(HttpMethod.POST))
                .andExpect(header("Authorization", "Bearer secret-token"))
                .andRespond(withSuccess("{\"data\":{\"suggestion\":\"pass\"}}", MediaType.APPLICATION_JSON));
        ImageContentModerationService service = service(restTemplate, true, ENDPOINT, "secret-token", true);

        assertDoesNotThrow(() -> service.moderate(image()));

        server.verify();
    }

    @Test
    void blockResponseRejectsImage() {
        RestTemplate restTemplate = new RestTemplate();
        MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();
        server.expect(requestTo(ENDPOINT))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withSuccess("{\"decision\":\"block\"}", MediaType.APPLICATION_JSON));
        ImageContentModerationService service = service(restTemplate, true, ENDPOINT, "", true);

        ApiException exception = assertThrows(ApiException.class, () -> service.moderate(image()));

        assertEquals(400, exception.getStatus());
        assertEquals("图片内容合规检测未通过", exception.getMessage());
        server.verify();
    }

    @Test
    void blockDecisionTakesPrecedenceOverPassSignal() {
        RestTemplate restTemplate = new RestTemplate();
        MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();
        server.expect(requestTo(ENDPOINT))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withSuccess("{\"safe\":true,\"data\":{\"suggestion\":\"review\"}}", MediaType.APPLICATION_JSON));
        ImageContentModerationService service = service(restTemplate, true, ENDPOINT, "", true);

        ApiException exception = assertThrows(ApiException.class, () -> service.moderate(image()));

        assertEquals(400, exception.getStatus());
        server.verify();
    }

    @Test
    void ambiguousResponseFailsClosed() {
        RestTemplate restTemplate = new RestTemplate();
        MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();
        server.expect(requestTo(ENDPOINT))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withSuccess("{\"code\":0}", MediaType.APPLICATION_JSON));
        ImageContentModerationService service = service(restTemplate, true, ENDPOINT, "", true);

        ApiException exception = assertThrows(ApiException.class, () -> service.moderate(image()));

        assertEquals(503, exception.getStatus());
        assertEquals("图片内容合规检测服务不可用", exception.getMessage());
        server.verify();
    }

    @Test
    void endpointFailureCanFailOpenForDevelopment() {
        RestTemplate restTemplate = new RestTemplate();
        MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();
        server.expect(requestTo(ENDPOINT))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withServerError());
        ImageContentModerationService service = service(restTemplate, true, ENDPOINT, "", false);

        assertDoesNotThrow(() -> service.moderate(image()));

        server.verify();
    }

    private ImageContentModerationService service(RestTemplate restTemplate,
                                                  boolean enabled,
                                                  String endpoint,
                                                  String apiKey,
                                                  boolean failClosed) {
        return new ImageContentModerationService(restTemplate, new ObjectMapper(), enabled, endpoint, apiKey, failClosed);
    }

    private MockMultipartFile image() {
        return new MockMultipartFile("file", "image.png", "image/png", "png".getBytes(StandardCharsets.UTF_8));
    }
}
