import base64
import hashlib
import hmac
import io
import json
import os
import tempfile
import time
import uuid
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

db_path = Path(tempfile.gettempdir()) / f"chat-service-test-{uuid.uuid4().hex}.sqlite3"
os.environ["CHAT_DATABASE_URL"] = f"sqlite:///{db_path}"
os.environ["CHAT_JWT_SECRET"] = "test-secret-for-chat-service-32-bytes-minimum"
os.environ["CHAT_AUTH_ENABLED"] = "true"
os.environ["CHAT_SEED_DEFAULTS"] = "true"
os.environ["CHAT_VECTOR_ENABLED"] = "false"
os.environ["CHAT_INGESTION_INLINE"] = "true"
os.environ["CHAT_DOCUMENT_DIR"] = str(Path(tempfile.gettempdir()) / f"chat-documents-{uuid.uuid4().hex}")

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def sign_token(token_type="user", principal_id=1):
    now = int(time.time())
    claims = {
        "typ": "JWT",
        "type": token_type,
        "id": principal_id,
        "iat": now,
        "exp": now + 3600,
        "jti": str(uuid.uuid4()),
        "sub": f"{token_type}:{principal_id}",
    }
    if token_type == "user":
        claims["role"] = "user"
        claims["username"] = "user-test"
    else:
        claims["role"] = "superadmin"
        claims["username"] = "admin"
    header = {"alg": "HS256", "typ": "JWT"}
    secret = os.environ["CHAT_JWT_SECRET"].encode("utf-8")
    header_part = b64(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    payload_part = b64(json.dumps(claims, separators=(",", ":")).encode("utf-8"))
    signed = f"{header_part}.{payload_part}".encode("utf-8")
    signature = b64(hmac.new(secret, signed, hashlib.sha256).digest())
    return f"{header_part}.{payload_part}.{signature}"


def b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")


def auth(token_type="user", principal_id=1):
    return {"Authorization": "Bearer " + sign_token(token_type, principal_id)}


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_metrics_endpoints():
    client.get("/health")

    response = client.get("/api/chat/metrics")
    assert response.status_code == 200
    data = response.json()
    assert data["service"] == "chat-service"
    assert data["requestsTotal"] >= 1
    assert data["statusCounts"]["200"] >= 1
    assert data["pathCounts"]["/health"] >= 1
    assert "requestDurationSeconds" in data

    prometheus = client.get("/metrics")
    assert prometheus.status_code == 200
    assert "chat_service_requests_total" in prometheus.text


def test_ask_requires_token():
    response = client.post("/api/chat/ask", json={"question": "怎么下单"})
    assert response.status_code == 401


def test_ask_uses_seeded_knowledge():
    response = client.post("/api/chat/ask", headers=auth("user"), json={"question": "证件照怎么换底色"})
    assert response.status_code == 200
    data = response.json()
    assert data["source"] == "knowledge"
    assert "证件照" in data["answer"]
    assert data["sources"]


def test_user_cannot_manage_knowledge():
    response = client.get("/api/chat/knowledge", headers=auth("user"))
    assert response.status_code == 403


def test_user_cannot_import_knowledge():
    payload = {
        "filename": "faq.csv",
        "contentBase64": base64.b64encode("question,answer\nQ,A\n".encode("utf-8")).decode("utf-8"),
    }
    response = client.post("/api/chat/knowledge/import", headers=auth("user"), json=payload)
    assert response.status_code == 403


def test_admin_can_import_csv_knowledge():
    csv_content = "\n".join(
        [
            "question,answer,category,tags,enabled",
            "批量导入怎么用？,后台上传 CSV 或 XLSX 文件导入 FAQ。,客服,\"导入,FAQ\",true",
            "证件照可以做哪些处理？,重复问题会被跳过,证件照,,true",
            ",缺少问题会失败,通用,,true",
        ]
    )
    payload = {
        "filename": "faq.csv",
        "contentBase64": base64.b64encode(csv_content.encode("utf-8-sig")).decode("utf-8"),
    }

    response = client.post("/api/chat/knowledge/import", headers=auth("admin"), json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["totalRows"] == 3
    assert data["imported"] == 1
    assert data["skipped"] == 1
    assert data["failed"] == 1
    assert data["errors"][0]["row"] == 4

    listed = client.get("/api/chat/knowledge?keyword=批量导入", headers=auth("admin"))
    assert listed.status_code == 200
    assert listed.json()["total"] == 1
    assert listed.json()["items"][0]["tags"] == ["导入", "FAQ"]


def test_admin_can_import_xlsx_knowledge():
    xlsx_content = build_xlsx(
        [
            ["问题", "答案", "分类", "标签", "状态"],
            ["XLSX 可以导入吗？", "可以，后台支持 XLSX FAQ 批量导入。", "客服", "Excel；FAQ", "启用"],
        ]
    )
    payload = {
        "filename": "faq.xlsx",
        "contentBase64": base64.b64encode(xlsx_content).decode("utf-8"),
    }

    response = client.post("/api/chat/knowledge/import", headers=auth("admin"), json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["imported"] == 1
    assert data["skipped"] == 0
    assert data["failed"] == 0

    listed = client.get("/api/chat/knowledge?keyword=XLSX 可以导入吗", headers=auth("admin"))
    assert listed.status_code == 200
    assert listed.json()["total"] == 1
    item = listed.json()["items"][0]
    assert item["category"] == "客服"
    assert item["tags"] == ["Excel", "FAQ"]


def test_admin_can_create_update_delete_knowledge():
    payload = {
        "question": "营业时间是什么？",
        "answer": "门店营业时间以小程序附近网点页面展示为准。",
        "category": "门店",
        "tags": ["营业时间", "门店"],
        "enabled": True,
    }
    created = client.post("/api/chat/knowledge/create", headers=auth("admin"), json=payload)
    assert created.status_code == 200
    item_id = created.json()["id"]

    listed = client.get("/api/chat/knowledge?keyword=营业时间", headers=auth("admin"))
    assert listed.status_code == 200
    assert listed.json()["total"] >= 1

    payload["answer"] = "请在小程序附近网点页查看最新营业时间。"
    updated = client.put(f"/api/chat/knowledge/{item_id}", headers=auth("admin"), json=payload)
    assert updated.status_code == 200
    assert "附近网点" in updated.json()["answer"]

    deleted = client.delete(f"/api/chat/knowledge/{item_id}", headers=auth("admin"))
    assert deleted.status_code == 200
    assert deleted.json()["deleted"] is True


def test_admin_can_disable_and_enable_chat():
    current = client.get("/api/chat/settings", headers=auth("admin"))
    assert current.status_code == 200
    payload = current.json()
    payload.pop("updatedBy", None)
    payload.pop("updatedAt", None)
    payload["enabled"] = False

    disabled = client.put("/api/chat/settings", headers=auth("admin"), json=payload)
    assert disabled.status_code == 200
    assert disabled.json()["enabled"] is False
    status = client.get("/api/chat/status")
    assert status.json()["enabled"] is False
    blocked = client.post("/api/chat/ask", headers=auth("user"), json={"question": "怎么打印"})
    assert blocked.status_code == 503

    payload["enabled"] = True
    enabled = client.put("/api/chat/settings", headers=auth("admin"), json=payload)
    assert enabled.status_code == 200
    assert enabled.json()["enabled"] is True


def test_conversation_history_is_owned_and_feedback_is_recorded():
    first = client.post("/api/chat/ask", headers=auth("user"), json={"question": "怎么联系人工客服"})
    assert first.status_code == 200
    session_id = first.json()["sessionId"]
    message_id = first.json()["messageId"]

    second = client.post(
        "/api/chat/ask",
        headers=auth("user"),
        json={"question": "服务时间呢", "sessionId": session_id},
    )
    assert second.status_code == 200
    history = client.get(f"/api/chat/conversations/{session_id}/messages", headers=auth("user"))
    assert history.status_code == 200
    assert [item["role"] for item in history.json()["messages"]] == ["user", "assistant", "user", "assistant"]

    denied = client.get(f"/api/chat/conversations/{session_id}/messages", headers=auth("user", 2))
    assert denied.status_code == 404
    feedback = client.post(
        "/api/chat/feedback",
        headers=auth("user"),
        json={"messageId": message_id, "rating": 1, "comment": "有帮助"},
    )
    assert feedback.status_code == 200
    assert feedback.json()["rating"] == 1


def test_admin_can_import_markdown_and_preview_chunks():
    markdown = """# 打印平台规则

## 订单取件

订单进入待取件状态后，请携带取件码到所选门店领取。

<script>ignore me</script>

## 打印价格

订单价格由服务单价、页数和份数计算，以提交订单时页面显示为准。
"""
    payload = {
        "filename": "platform-guide.md",
        "title": "打印平台规则",
        "category": "项目文档",
        "contentBase64": base64.b64encode(markdown.encode("utf-8")).decode("utf-8"),
    }
    imported = client.post("/api/chat/documents/import", headers=auth("admin"), json=payload)
    assert imported.status_code == 200
    document = imported.json()
    assert document["status"] == "keyword_only"
    assert document["chunkCount"] >= 2

    chunks = client.get(f"/api/chat/documents/{document['id']}/chunks", headers=auth("admin"))
    assert chunks.status_code == 200
    assert all("<script>" not in item["content"] for item in chunks.json())
    assert any("订单取件" in item["heading"] for item in chunks.json())

    answer = client.post("/api/chat/ask", headers=auth("user"), json={"question": "订单进入待取件状态后应该怎么做"})
    assert answer.status_code == 200
    assert "取件码" in answer.json()["answer"]
    assert any(source["sourceType"] == "document" for source in answer.json()["sources"])


def test_agent_executes_only_allowed_tool(monkeypatch):
    from app.main import agent
    from app.schemas import ToolExecutionResult

    class FakeLlm:
        available = True

        def __init__(self):
            self.calls = 0

        def complete(self, **kwargs):
            self.calls += 1
            if self.calls == 1:
                return {
                    "content": "",
                    "tool_calls": [
                        {"id": "call-1", "type": "function", "function": {"name": "list_my_orders", "arguments": "{}"}}
                    ],
                }
            return {"content": "你最近有一个待处理订单。"}

    class FakeTools:
        def definitions(self, allowed_tools):
            from app.tools import PlatformToolExecutor
            return PlatformToolExecutor().definitions(allowed_tools)

        def execute(self, name, arguments, principal, hotline, service_hours, handoff_message=""):
            assert name == "list_my_orders"
            assert "user_id" not in arguments
            assert principal.id == 1
            return ToolExecutionResult(ok=True, data=[{"orderId": 9, "status": "待处理"}], summary="已查询最近 1 个订单")

    monkeypatch.setattr(agent, "llm", FakeLlm())
    monkeypatch.setattr(agent, "tools", FakeTools())
    response = client.post("/api/chat/ask", headers=auth("user"), json={"question": "查询我最近的订单"})
    assert response.status_code == 200
    data = response.json()
    assert data["source"] == "agent"
    assert data["toolCalls"][0]["tool"] == "list_my_orders"
    assert data["toolCalls"][0]["status"] == "completed"


def test_settings_persist_prompt_version_and_handoff_message():
    current = client.get("/api/chat/settings", headers=auth("admin"))
    assert current.status_code == 200
    payload = current.json()
    payload.pop("updatedBy", None)
    payload.pop("updatedAt", None)
    payload["systemPromptVersion"] = "v2-handoff"
    payload["handoffMessage"] = "请联系人工客服协助处理当前问题。"
    payload["allowedTools"] = ["search_knowledge", "handoff_to_human", "list_my_orders"]

    updated = client.put("/api/chat/settings", headers=auth("admin"), json=payload)
    assert updated.status_code == 200
    data = updated.json()
    assert data["systemPromptVersion"] == "v2-handoff"
    assert data["handoffMessage"] == "请联系人工客服协助处理当前问题。"
    assert "search_knowledge" in data["allowedTools"]

    reloaded = client.get("/api/chat/settings", headers=auth("admin"))
    assert reloaded.status_code == 200
    assert reloaded.json()["systemPromptVersion"] == "v2-handoff"
    assert reloaded.json()["handoffMessage"] == "请联系人工客服协助处理当前问题。"


def test_agent_search_knowledge_tool_is_audited(monkeypatch):
    from app.agent import RetrievedContext
    from app.main import agent
    from app.schemas import AskSource

    class FakeLlm:
        available = True

        def __init__(self):
            self.calls = 0

        def complete(self, **kwargs):
            self.calls += 1
            if self.calls == 1:
                return {
                    "content": "",
                    "tool_calls": [
                        {
                            "id": "call-search",
                            "type": "function",
                            "function": {"name": "search_knowledge", "arguments": '{"query":"取件码"}'},
                        }
                    ],
                }
            return {"content": "订单待取件后请携带取件码到门店领取。"}

    class FakeRetriever:
        def __init__(self):
            self.queries = []

        def search(self, query, limit=6):
            self.queries.append(query)
            return [
                RetrievedContext(
                    content="订单进入待取件状态后，请携带取件码到所选门店领取。",
                    source=AskSource(
                        id=101,
                        question="订单取件",
                        category="项目文档",
                        score=0.91,
                        sourceType="document",
                        documentId=9,
                        title="打印平台规则",
                    ),
                )
            ]

    current = client.get("/api/chat/settings", headers=auth("admin")).json()
    payload = {key: value for key, value in current.items() if key not in {"updatedBy", "updatedAt"}}
    payload["mode"] = "agent"
    payload["deepseekEnabled"] = True
    payload["allowedTools"] = ["search_knowledge"]
    assert client.put("/api/chat/settings", headers=auth("admin"), json=payload).status_code == 200

    fake_retriever = FakeRetriever()
    monkeypatch.setattr(agent, "llm", FakeLlm())
    monkeypatch.setattr(agent, "retriever", fake_retriever)
    response = client.post("/api/chat/ask", headers=auth("user"), json={"question": "取件码怎么用"})
    assert response.status_code == 200
    data = response.json()
    assert data["source"] == "agent"
    assert data["toolCalls"][0]["tool"] == "search_knowledge"
    assert data["toolCalls"][0]["status"] == "completed"
    assert "取件码" in data["answer"]
    assert "取件码" in fake_retriever.queries


def test_admin_can_replace_document_and_see_ingestion_progress():
    markdown_v1 = "# 规则 V1\n\n## 取件\n\n旧版取件说明。"
    imported = client.post(
        "/api/chat/documents/import",
        headers=auth("admin"),
        json={
            "filename": "replace-guide.md",
            "title": "规则 V1",
            "category": "项目文档",
            "contentBase64": base64.b64encode(markdown_v1.encode("utf-8")).decode("utf-8"),
        },
    )
    assert imported.status_code == 200
    document = imported.json()
    assert document["version"] == 1
    assert document["ingestionStatus"] in {"pending", "processing", "completed", "failed", ""}
    assert isinstance(document["ingestionProgress"], int)

    markdown_v2 = "# 规则 V2\n\n## 取件\n\n新版取件说明，请携带取件码领取。"
    replaced = client.post(
        f"/api/chat/documents/{document['id']}/replace",
        headers=auth("admin"),
        json={
            "filename": "replace-guide.md",
            "title": "规则 V2",
            "category": "项目文档",
            "contentBase64": base64.b64encode(markdown_v2.encode("utf-8")).decode("utf-8"),
        },
    )
    assert replaced.status_code == 200
    new_document = replaced.json()
    assert new_document["version"] == 2
    assert new_document["title"] == "规则 V2"
    assert new_document["id"] != document["id"]
    assert new_document["ingestionProgress"] >= 0

    listed = client.get("/api/chat/documents", headers=auth("admin"))
    assert listed.status_code == 200
    versions = [item for item in listed.json()["items"] if item["filename"] == "replace-guide.md"]
    assert len(versions) >= 2
    assert any(item.get("ingestionStatus") is not None for item in versions)


def test_admin_retrieval_test_requires_admin_and_returns_sources():
    denied = client.post(
        "/api/chat/documents/retrieval-test",
        headers=auth("user"),
        json={"query": "取件码", "limit": 3},
    )
    assert denied.status_code == 403

    markdown = "# 检索测试\n\n## 取件说明\n\n请携带取件码到门店领取打印件。"
    imported = client.post(
        "/api/chat/documents/import",
        headers=auth("admin"),
        json={
            "filename": "retrieval-test.md",
            "title": "检索测试文档",
            "category": "项目文档",
            "contentBase64": base64.b64encode(markdown.encode("utf-8")).decode("utf-8"),
        },
    )
    assert imported.status_code == 200

    response = client.post(
        "/api/chat/documents/retrieval-test",
        headers=auth("admin"),
        json={"query": "取件码到门店领取", "limit": 5},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["query"] == "取件码到门店领取"
    assert isinstance(data["sources"], list)
    assert any(source["sourceType"] in {"document", "faq"} for source in data["sources"])


def build_xlsx(rows):
    shared_strings = []
    shared_indexes = {}

    def shared_index(value):
        text = str(value)
        if text not in shared_indexes:
            shared_indexes[text] = len(shared_strings)
            shared_strings.append(text)
        return shared_indexes[text]

    sheet_rows = []
    for row_index, row in enumerate(rows, start=1):
        cells = []
        for column_index, value in enumerate(row, start=1):
            reference = f"{column_name(column_index)}{row_index}"
            cells.append(f'<c r="{reference}" t="s"><v>{shared_index(value)}</v></c>')
        sheet_rows.append(f'<row r="{row_index}">{"".join(cells)}</row>')

    shared_xml = "".join(f"<si><t>{escape(value)}</t></si>" for value in shared_strings)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as workbook:
        workbook.writestr(
            "xl/worksheets/sheet1.xml",
            f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>{"".join(sheet_rows)}</sheetData></worksheet>',
        )
        workbook.writestr(
            "xl/sharedStrings.xml",
            f'<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="{len(shared_strings)}" uniqueCount="{len(shared_strings)}">{shared_xml}</sst>',
        )
    return buffer.getvalue()


def column_name(index):
    name = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        name = chr(65 + remainder) + name
    return name
