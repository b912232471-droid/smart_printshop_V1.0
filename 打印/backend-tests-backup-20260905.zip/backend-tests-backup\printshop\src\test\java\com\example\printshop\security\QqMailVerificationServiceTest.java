package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.mail.javamail.JavaMailSender;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class QqMailVerificationServiceTest {
    private StringRedisTemplate redisTemplate;
    private FieldCryptoService cryptoService;

    @BeforeEach
    void setUp() {
        redisTemplate = mock(StringRedisTemplate.class);
        cryptoService = new FieldCryptoService("test-mail-verification-key-123456789");
    }

    @Test
    void disabledMailServiceRejectsSending() {
        QqMailVerificationService service = service(false, "");

        ApiException exception = assertThrows(ApiException.class,
                () -> service.send("123456@qq.com", QqMailVerificationService.REGISTER));

        assertEquals(503, exception.getStatus());
    }

    @Test
    void rejectsMalformedVerificationCode() {
        QqMailVerificationService service = service(true, "123456@qq.com");

        assertThrows(ApiException.class,
                () -> service.verify("123456@qq.com", QqMailVerificationService.REGISTER, "12345"));
    }

    @Test
    void consumesMatchingCodeAtomically() {
        QqMailVerificationService service = service(true, "123456@qq.com");
        when(redisTemplate.execute(any(), anyList(), any())).thenReturn(1L);

        service.verify("123456@qq.com", QqMailVerificationService.RESET_PASSWORD, "123456");
    }

    private QqMailVerificationService service(boolean enabled, String from) {
        return new QqMailVerificationService(
                mock(JavaMailSender.class), redisTemplate, cryptoService,
                enabled, from, 300, 60, 20);
    }
}
