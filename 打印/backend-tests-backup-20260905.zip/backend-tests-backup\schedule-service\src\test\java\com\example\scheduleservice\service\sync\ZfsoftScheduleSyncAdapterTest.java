package com.example.scheduleservice.service.sync;

import com.example.scheduleservice.common.ApiException;
import com.example.scheduleservice.model.CourseSchedule;
import com.example.scheduleservice.model.JwAccount;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPublicKey;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ZfsoftScheduleSyncAdapterTest {
    private static final String KB_JSON = """
            {
              "kbList": [
                {"kcmc": "项目开发综合实训", "xqj": "1", "jcs": "1-8", "cdmc": "新工科大楼216", "xm": "张老师"},
                {"KCMC": "数据结构", "XQJ": "3", "JCS": "3-4", "CDMC": "教学楼301", "XM": "李老师"}
              ]
            }
            """;

    private HttpServer server;
    private final AtomicReference<String> kbQuery = new AtomicReference<>();
    private final AtomicReference<String> loginBody = new AtomicReference<>();
    private final AtomicReference<String> kbCookie = new AtomicReference<>();
    private final ConcurrentHashMap<String, String> sessions = new ConcurrentHashMap<>();
    private final AtomicReference<String> kbBody = new AtomicReference<>("null");
    private KeyPair keyPair;

    @BeforeEach
    void setUp() throws Exception {
        keyPair = KeyPairGenerator.getInstance("RSA").genKeyPair();
    }

    @AfterEach
    void tearDown() {
        if (server != null) {
            server.stop(0);
        }
    }

    @Test
    void fetchCoursesLogsInWithRsaAndParsesKbList() throws Exception {
        startServer(true);
        kbBody.set(KB_JSON);
        ZfsoftScheduleSyncAdapter adapter = new ZfsoftScheduleSyncAdapter(
                true, "http://127.0.0.1:" + server.getAddress().getPort(), "N253508", 5000);
        JwAccount account = new JwAccount(1L, 7L, "20231070129", "secret");

        List<CourseSchedule> courses = adapter.fetchCourses(7L, account, "secret", "2026-2027", "1");

        assertEquals(2, courses.size());
        CourseSchedule first = courses.get(0);
        assertEquals("项目开发综合实训", first.kcmc());
        assertEquals("1", first.xqj());
        assertEquals("1-8", first.jcs());
        assertEquals("新工科大楼216", first.cdmc());
        assertEquals("张老师", first.xm());
        assertEquals("2026-2027", courses.get(1).xnm());
        assertEquals("数据结构", courses.get(1).kcmc());

        assertTrue(kbQuery.get().contains("xnm=2026"));
        assertTrue(kbQuery.get().contains("xqm=3"));
        assertTrue(kbQuery.get().contains("kzlx=ck"));
        assertTrue(kbCookie.get() != null && !kbCookie.get().isBlank());

        String loginForm = loginBody.get();
        assertTrue(loginForm.startsWith("yhm=20231070129"));
        assertFalse(loginForm.contains("secret"));
        assertTrue(loginForm.contains("csrftoken="));
    }

    @Test
    void fetchCoursesReturnsEmptyListWhenKbListMissing() throws Exception {
        startServer(true);
        kbBody.set("null");
        ZfsoftScheduleSyncAdapter adapter = new ZfsoftScheduleSyncAdapter(
                true, "http://127.0.0.1:" + server.getAddress().getPort(), "N253508", 5000);
        JwAccount account = new JwAccount(1L, 7L, "20231070129", "secret");

        List<CourseSchedule> courses = adapter.fetchCourses(7L, account, "secret", "2025-2026", "2");

        assertTrue(courses.isEmpty());
        assertTrue(kbQuery.get().contains("xnm=2025"));
        assertTrue(kbQuery.get().contains("xqm=12"));
    }

    @Test
    void fetchCoursesThrowsBadRequestWhenLoginRejected() throws Exception {
        startServer(false);
        ZfsoftScheduleSyncAdapter adapter = new ZfsoftScheduleSyncAdapter(
                true, "http://127.0.0.1:" + server.getAddress().getPort(), "N253508", 5000);
        JwAccount account = new JwAccount(1L, 7L, "20231070129", "wrong");

        ApiException exception = assertThrows(ApiException.class,
                () -> adapter.fetchCourses(7L, account, "wrong", "2026-2027", "1"));

        assertEquals(400, exception.getStatus());
        assertTrue(exception.getMessage().contains("用户名或密码不正确"));
    }

    @Test
    void adapterIsDisabledWithoutBaseUrl() {
        assertFalse(new ZfsoftScheduleSyncAdapter(true, "", "N253508", 5000).isConfigured());
        assertFalse(new ZfsoftScheduleSyncAdapter(false, "https://jw.unn.edu.cn", "N253508", 5000).isConfigured());
    }

    private void startServer(boolean loginSucceeds) throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/xtgl/login_slogin.html", exchange -> {
            if ("GET".equals(exchange.getRequestMethod())) {
                byte[] body = ("<html><input type=\"hidden\" id=\"csrftoken\" name=\"csrftoken\" value=\"token-123,token123\"/></html>")
                        .getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().add("Content-Type", "text/html;charset=UTF-8");
                exchange.sendResponseHeaders(200, body.length);
                exchange.getResponseBody().write(body);
            } else {
                loginBody.set(readBody(exchange));
                if (loginSucceeds) {
                    sessions.put("session-abc", "20231070129");
                    exchange.getResponseHeaders().add("Set-Cookie", "JSESSIONID=session-abc; Path=/");
                    exchange.getResponseHeaders().add("Location", "/xtgl/index_initMenu.html");
                    exchange.sendResponseHeaders(302, -1);
                } else {
                    byte[] body = ("<html><div id=\"tips\">用户名或密码不正确</div></html>").getBytes(StandardCharsets.UTF_8);
                    exchange.getResponseHeaders().add("Content-Type", "text/html;charset=UTF-8");
                    exchange.sendResponseHeaders(200, body.length);
                    exchange.getResponseBody().write(body);
                }
            }
            exchange.close();
        });
        server.createContext("/xtgl/login_getPublicKey.html", exchange -> {
            RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
            String json = "{\"modulus\":\"" + Base64.getEncoder().encodeToString(publicKey.getModulus().toByteArray())
                    + "\",\"exponent\":\"" + Base64.getEncoder().encodeToString(publicKey.getPublicExponent().toByteArray())
                    + "\"}";
            byte[] body = json.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "application/json;charset=UTF-8");
            exchange.sendResponseHeaders(200, body.length);
            exchange.getResponseBody().write(body);
            exchange.close();
        });
        server.createContext("/xtgl/index_initMenu.html", exchange -> {
            exchange.sendResponseHeaders(200, 0);
            exchange.close();
        });
        server.createContext("/kbcx/xskbcx_cxXsgrkb.html", exchange -> {
            kbQuery.set(readBody(exchange));
            kbCookie.set(exchange.getRequestHeaders().getFirst("Cookie"));
            String body = kbBody.get();
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "application/json;charset=UTF-8");
            exchange.sendResponseHeaders(200, bytes.length);
            exchange.getResponseBody().write(bytes);
            exchange.close();
        });
        server.start();
    }

    private String readBody(HttpExchange exchange) throws IOException {
        try (InputStream stream = exchange.getRequestBody()) {
            return new String(stream.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
