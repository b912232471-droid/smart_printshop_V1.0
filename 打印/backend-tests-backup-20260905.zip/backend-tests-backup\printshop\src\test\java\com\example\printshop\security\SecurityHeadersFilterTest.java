package com.example.printshop.security;

import jakarta.servlet.ServletException;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class SecurityHeadersFilterTest {

    @Test
    void rejectsSpoofedForwardedProtoWhenForwardedHeadersAreNotTrusted() throws ServletException, IOException {
        SecurityHeadersFilter filter = new SecurityHeadersFilter(true, false);
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/order/1");
        request.setSecure(false);
        request.addHeader("X-Forwarded-Proto", "https");
        MockHttpServletResponse response = new MockHttpServletResponse();

        filter.doFilter(request, response, new MockFilterChain());

        assertEquals(403, response.getStatus());
        assertNull(response.getHeader("Strict-Transport-Security"));
    }

    @Test
    void allowsForwardedHttpsOnlyWhenForwardedHeadersAreTrusted() throws ServletException, IOException {
        SecurityHeadersFilter filter = new SecurityHeadersFilter(true, true);
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/order/1");
        request.setSecure(false);
        request.addHeader("X-Forwarded-Proto", "https, http");
        MockHttpServletResponse response = new MockHttpServletResponse();

        filter.doFilter(request, response, new MockFilterChain());

        assertEquals(200, response.getStatus());
        assertEquals("max-age=31536000; includeSubDomains", response.getHeader("Strict-Transport-Security"));
    }

    @Test
    void secureRequestReceivesSecurityHeadersAndHsts() throws ServletException, IOException {
        SecurityHeadersFilter filter = new SecurityHeadersFilter(true, false);
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/order/1");
        request.setSecure(true);
        MockHttpServletResponse response = new MockHttpServletResponse();

        filter.doFilter(request, response, new MockFilterChain());

        assertEquals(200, response.getStatus());
        assertEquals("nosniff", response.getHeader("X-Content-Type-Options"));
        assertEquals("DENY", response.getHeader("X-Frame-Options"));
        assertEquals("no-store", response.getHeader("Cache-Control"));
        assertEquals("max-age=31536000; includeSubDomains", response.getHeader("Strict-Transport-Security"));
    }
}
