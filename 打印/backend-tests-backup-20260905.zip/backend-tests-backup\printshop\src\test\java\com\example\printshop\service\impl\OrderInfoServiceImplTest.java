package com.example.printshop.service.impl;

import com.example.printshop.common.ApiException;
import com.example.printshop.entity.OrderInfo;
import com.example.printshop.entity.ServiceItem;
import com.example.printshop.entity.Store;
import com.example.printshop.mapper.OrderInfoMapper;
import com.example.printshop.security.AuditService;
import com.example.printshop.service.ServiceItemService;
import com.example.printshop.service.StoreService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class OrderInfoServiceImplTest {
    private OrderInfoMapper orderInfoMapper;
    private AuditService auditService;
    private ServiceItemService serviceItemService;
    private StoreService storeService;
    private OrderInfoServiceImpl service;

    @BeforeEach
    void setUp() {
        orderInfoMapper = mock(OrderInfoMapper.class);
        auditService = mock(AuditService.class);
        serviceItemService = mock(ServiceItemService.class);
        storeService = mock(StoreService.class);
        service = new OrderInfoServiceImpl();
        ReflectionTestUtils.setField(service, "orderInfoMapper", orderInfoMapper);
        ReflectionTestUtils.setField(service, "auditService", auditService);
        ReflectionTestUtils.setField(service, "serviceItemService", serviceItemService);
        ReflectionTestUtils.setField(service, "storeService", storeService);
    }

    @Test
    void createOrderDefaultsToPendingStatus() {
        OrderInfo order = validOrder();
        when(serviceItemService.getById(1)).thenReturn(serviceItem(1.50));
        when(storeService.getById(2)).thenReturn(store(1));
        when(orderInfoMapper.insert(order)).thenReturn(1);

        int rows = service.createOrder(order);

        assertEquals(1, rows);
        assertEquals(0, order.getOrderStatus());
        assertEquals(1, order.getCopies());
        assertEquals(1, order.getPageCount());
        assertEquals(0, order.getDuplex());
        assertEquals("BLACK_WHITE", order.getColorMode());
        assertEquals("A4", order.getPaperSize());
        assertEquals(1.50, order.getTotalPrice());
    }

    @Test
    void createOrderRejectsNonPendingInitialStatus() {
        OrderInfo order = new OrderInfo();
        order.setOrderStatus(1);

        ApiException exception = assertThrows(ApiException.class, () -> service.createOrder(order));

        assertEquals(400, exception.getStatus());
    }

    @Test
    void createOrderRejectsUnknownService() {
        OrderInfo order = validOrder();
        when(serviceItemService.getById(1)).thenReturn(null);

        ApiException exception = assertThrows(ApiException.class, () -> service.createOrder(order));

        assertEquals(400, exception.getStatus());
        assertEquals("服务项目不存在", exception.getMessage());
    }

    @Test
    void createOrderRejectsUnknownStore() {
        OrderInfo order = validOrder();
        when(serviceItemService.getById(1)).thenReturn(serviceItem(1.50));
        when(storeService.getById(2)).thenReturn(null);

        ApiException exception = assertThrows(ApiException.class, () -> service.createOrder(order));

        assertEquals(400, exception.getStatus());
        assertEquals("门店不存在", exception.getMessage());
    }

    @Test
    void createOrderRejectsClosedStore() {
        OrderInfo order = validOrder();
        when(serviceItemService.getById(1)).thenReturn(serviceItem(1.50));
        when(storeService.getById(2)).thenReturn(store(0));

        ApiException exception = assertThrows(ApiException.class, () -> service.createOrder(order));

        assertEquals(400, exception.getStatus());
        assertEquals("门店已关闭，不能下单", exception.getMessage());
    }

    @Test
    void createOrderCalculatesPriceFromPagesAndCopies() {
        OrderInfo order = validOrder();
        order.setTotalPrice(0.01);
        order.setPageCount(3);
        order.setCopies(2);
        order.setDuplex(1);
        order.setColorMode("color");
        order.setPaperSize("A3");
        when(serviceItemService.getById(1)).thenReturn(serviceItem(1.50));
        when(storeService.getById(2)).thenReturn(store(1));
        when(orderInfoMapper.insert(order)).thenReturn(1);

        int rows = service.createOrder(order);

        assertEquals(1, rows);
        assertEquals(9.00, order.getTotalPrice());
        assertEquals("COLOR", order.getColorMode());
    }

    @Test
    void createOrderRejectsInvalidCopies() {
        OrderInfo order = validOrder();
        order.setCopies(0);
        when(serviceItemService.getById(1)).thenReturn(serviceItem(1.00));
        when(storeService.getById(2)).thenReturn(store(1));

        ApiException exception = assertThrows(ApiException.class, () -> service.createOrder(order));

        assertEquals(400, exception.getStatus());
        assertEquals("打印份数不合法", exception.getMessage());
    }

    @Test
    void createOrderRejectsInvalidColorMode() {
        OrderInfo order = validOrder();
        order.setColorMode("rgb");
        when(serviceItemService.getById(1)).thenReturn(serviceItem(1.00));
        when(storeService.getById(2)).thenReturn(store(1));

        ApiException exception = assertThrows(ApiException.class, () -> service.createOrder(order));

        assertEquals(400, exception.getStatus());
        assertEquals("色彩参数不合法", exception.getMessage());
    }

    @Test
    void createOrderRejectsNonFiniteServicePrice() {
        OrderInfo order = validOrder();
        when(serviceItemService.getById(1)).thenReturn(serviceItem(Double.NaN));
        when(storeService.getById(2)).thenReturn(store(1));

        ApiException exception = assertThrows(ApiException.class, () -> service.createOrder(order));

        assertEquals(400, exception.getStatus());
        assertEquals("服务单价不合法", exception.getMessage());
    }

    @Test
    void updateStatusAllowsForwardTransitionAndPreservesExistingFetchCodeWhenBlank() {
        OrderInfo existing = order(1, 0, "123456");
        AtomicReference<OrderInfo> updated = new AtomicReference<>();
        when(orderInfoMapper.selectById(1)).thenReturn(existing);
        doAnswer(invocation -> {
            updated.set(invocation.getArgument(0, OrderInfo.class));
            return 1;
        }).when(orderInfoMapper).update(any(OrderInfo.class));

        int rows = service.updateOrderStatus(1, 1, "");

        assertEquals(1, rows);
        assertEquals(1, updated.get().getOrderStatus());
        assertEquals("123456", updated.get().getFetchCode());
        assertNotNull(updated.get().getUpdateTime());
        verify(auditService).record("order_status_change", "success", "orderId=1,from=0,to=1");
    }

    @Test
    void updateStatusRejectsBackwardTransition() {
        when(orderInfoMapper.selectById(1)).thenReturn(order(1, 2, "123456"));

        ApiException exception = assertThrows(ApiException.class, () -> service.updateOrderStatus(1, 1, null));

        assertEquals(400, exception.getStatus());
        assertEquals("非法订单状态流转", exception.getMessage());
    }

    @Test
    void updateStatusRejectsTerminalTransition() {
        when(orderInfoMapper.selectById(1)).thenReturn(order(1, 3, "123456"));

        ApiException exception = assertThrows(ApiException.class, () -> service.updateOrderStatus(1, 4, null));

        assertEquals(400, exception.getStatus());
    }

    @Test
    void updateStatusRejectsUnknownStatus() {
        ApiException exception = assertThrows(ApiException.class, () -> service.updateOrderStatus(1, 9, null));

        assertEquals(400, exception.getStatus());
        assertEquals("非法订单状态", exception.getMessage());
    }

    private OrderInfo validOrder() {
        OrderInfo order = new OrderInfo();
        order.setUserId(7);
        order.setServiceId(1);
        order.setStoreId(2);
        order.setTotalPrice(1.50);
        return order;
    }

    private ServiceItem serviceItem(Double price) {
        ServiceItem item = new ServiceItem();
        item.setId(1);
        item.setPrice(price);
        return item;
    }

    private Store store(Integer status) {
        Store store = new Store();
        store.setId(2);
        store.setStatus(status);
        return store;
    }

    private OrderInfo order(Integer id, Integer status, String fetchCode) {
        OrderInfo order = new OrderInfo();
        order.setId(id);
        order.setOrderStatus(status);
        order.setFetchCode(fetchCode);
        return order;
    }
}
