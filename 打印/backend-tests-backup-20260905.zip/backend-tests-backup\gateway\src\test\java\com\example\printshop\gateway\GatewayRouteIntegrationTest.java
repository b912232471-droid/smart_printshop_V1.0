package com.example.printshop.gateway;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.beans.factory.annotation.Autowired;
import reactor.core.publisher.Mono;
import reactor.netty.DisposableServer;
import reactor.netty.http.server.HttpServer;

import java.time.Duration;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
        "gateway.security.auth.enabled=false",
        "gateway.security.rate-limit.enabled=false",
        "gateway.security.request-log.enabled=false",
        "spring.cloud.nacos.discovery.enabled=false"
})
@AutoConfigureWebTestClient(timeout = "PT10S")
class GatewayRouteIntegrationTest {
    private static final MockBackend PRINT_SERVICE = MockBackend.start();
    private static final MockBackend PHOTO_SERVICE = MockBackend.start();
    private static final MockBackend SCHEDULE_SERVICE = MockBackend.start();
    private static final MockBackend CHAT_SERVICE = MockBackend.start();

    @Autowired
    private WebTestClient webTestClient;

    @DynamicPropertySource
    static void gatewayProperties(DynamicPropertyRegistry registry) {
        registry.add("PRINT_SERVICE_URI", PRINT_SERVICE::baseUrl);
        registry.add("PHOTO_SERVICE_URI", PHOTO_SERVICE::baseUrl);
        registry.add("SCHEDULE_SERVICE_URI", SCHEDULE_SERVICE::baseUrl);
        registry.add("CHAT_SERVICE_URI", CHAT_SERVICE::baseUrl);
    }

    @BeforeEach
    void clearRecordedRequests() {
        PRINT_SERVICE.clear();
        PHOTO_SERVICE.clear();
        SCHEDULE_SERVICE.clear();
        CHAT_SERVICE.clear();
    }

    @AfterAll
    static void stopBackends() {
        PRINT_SERVICE.stop();
        PHOTO_SERVICE.stop();
        SCHEDULE_SERVICE.stop();
        CHAT_SERVICE.stop();
    }

    @Test
    void planPrefixRouteRewritesToPrintServiceApiPath() throws Exception {
        webTestClient.get()
                .uri("/api/print/order/123?status=1")
                .header(HttpHeaders.AUTHORIZATION, "Bearer route-test-token")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.path").isEqualTo("/api/order/123?status=1")
                .jsonPath("$.method").isEqualTo("GET");

        RecordedRequest request = PRINT_SERVICE.take();
        assertEquals("GET", request.method());
        assertEquals("/api/order/123?status=1", request.uri());
        assertEquals("Bearer route-test-token", request.authorization());
    }

    @Test
    void compatRouteForwardsApiPathWithoutRewrite() throws Exception {
        webTestClient.post()
                .uri("/api/order")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"id\":1}")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.path").isEqualTo("/api/order")
                .jsonPath("$.method").isEqualTo("POST");

        RecordedRequest request = PRINT_SERVICE.take();
        assertEquals("POST", request.method());
        assertEquals("/api/order", request.uri());
    }

    @Test
    void photoRouteForwardsToPhotoServiceBeforeCompatRoute() throws Exception {
        webTestClient.post()
                .uri("/api/photo/generate-id-photo")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"fileId\":1}")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.path").isEqualTo("/api/photo/generate-id-photo")
                .jsonPath("$.method").isEqualTo("POST");

        RecordedRequest request = PHOTO_SERVICE.take();
        assertEquals("POST", request.method());
        assertEquals("/api/photo/generate-id-photo", request.uri());
    }

    @Test
    void scheduleRouteForwardsToScheduleServiceBeforeCompatRoute() throws Exception {
        webTestClient.get()
                .uri("/api/schedule?term=2026-1")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.path").isEqualTo("/api/schedule?term=2026-1")
                .jsonPath("$.method").isEqualTo("GET");

        RecordedRequest request = SCHEDULE_SERVICE.take();
        assertEquals("GET", request.method());
        assertEquals("/api/schedule?term=2026-1", request.uri());
    }

    @Test
    void chatRouteForwardsToChatServiceBeforeCompatRoute() throws Exception {
        webTestClient.post()
                .uri("/api/chat/ask")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"question\":\"hello\"}")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.path").isEqualTo("/api/chat/ask")
                .jsonPath("$.method").isEqualTo("POST");

        RecordedRequest request = CHAT_SERVICE.take();
        assertEquals("POST", request.method());
        assertEquals("/api/chat/ask", request.uri());
    }

    private record RecordedRequest(String method, String uri, String authorization) {
    }

    private static class MockBackend {
        private final DisposableServer server;
        private final LinkedBlockingQueue<RecordedRequest> requests;

        private MockBackend(DisposableServer server, LinkedBlockingQueue<RecordedRequest> requests) {
            this.server = server;
            this.requests = requests;
        }

        static MockBackend start() {
            LinkedBlockingQueue<RecordedRequest> requests = new LinkedBlockingQueue<>();
            DisposableServer server = HttpServer.create()
                    .host("127.0.0.1")
                    .port(0)
                    .handle((request, response) -> {
                        String uri = request.uri();
                        String method = request.method().name();
                        String authorization = request.requestHeaders().get(HttpHeaders.AUTHORIZATION);
                        requests.add(new RecordedRequest(method, uri, authorization));
                        String body = "{\"method\":\"" + method + "\",\"path\":\"" + uri + "\"}";
                        return response.status(200)
                                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .sendString(Mono.just(body));
                    })
                    .bindNow(Duration.ofSeconds(5));
            return new MockBackend(server, requests);
        }

        String baseUrl() {
            return "http://127.0.0.1:" + server.port();
        }

        RecordedRequest take() throws InterruptedException {
            RecordedRequest request = requests.poll(5, TimeUnit.SECONDS);
            assertNotNull(request, "backend did not receive a request");
            return request;
        }

        void clear() {
            requests.clear();
        }

        void stop() {
            server.disposeNow();
        }
    }
}
