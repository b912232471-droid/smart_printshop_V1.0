package com.example.printshop.security;

import com.example.printshop.common.ApiException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class QqEmailAddressTest {
    @Test
    void normalizesQqEmail() {
        assertEquals("123456@qq.com", QqEmailAddress.normalize(" 123456@QQ.COM "));
    }

    @Test
    void rejectsNonQqAndMalformedEmail() {
        assertThrows(ApiException.class, () -> QqEmailAddress.normalize("user@example.com"));
        assertThrows(ApiException.class, () -> QqEmailAddress.normalize("12@qq.com"));
        assertThrows(ApiException.class, () -> QqEmailAddress.normalize(null));
    }
}
