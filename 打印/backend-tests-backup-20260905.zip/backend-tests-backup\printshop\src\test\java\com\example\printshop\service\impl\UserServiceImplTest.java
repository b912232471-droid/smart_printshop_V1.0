package com.example.printshop.service.impl;

import com.example.printshop.entity.User;
import com.example.printshop.mapper.UserMapper;
import com.example.printshop.security.FieldCryptoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class UserServiceImplTest {
    private UserMapper userMapper;
    private UserServiceImpl service;

    @BeforeEach
    void setUp() {
        userMapper = mock(UserMapper.class);
        service = new UserServiceImpl();
        ReflectionTestUtils.setField(service, "userMapper", userMapper);
        ReflectionTestUtils.setField(service, "fieldCryptoService", new FieldCryptoService("test-field-crypto-key-with-more-than-32-characters"));
    }

    @Test
    void getAllDecryptsEncryptedPhones() {
        FieldCryptoService crypto = new FieldCryptoService("test-field-crypto-key-with-more-than-32-characters");
        User user = new User();
        user.setId(5);
        user.setPhone(crypto.encryptNullable("13800000000"));
        when(userMapper.selectAll()).thenReturn(List.of(user));

        List<User> users = service.getAllUsers();

        assertEquals("13800000000", users.get(0).getPhone());
    }
}
