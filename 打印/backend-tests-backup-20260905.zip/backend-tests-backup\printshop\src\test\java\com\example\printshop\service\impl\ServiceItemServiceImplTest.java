package com.example.printshop.service.impl;

import com.example.printshop.common.ApiException;
import com.example.printshop.entity.ServiceItem;
import com.example.printshop.mapper.ServiceItemMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ServiceItemServiceImplTest {
    private ServiceItemMapper mapper;
    private ServiceItemServiceImpl service;

    @BeforeEach
    void setUp() {
        mapper = mock(ServiceItemMapper.class);
        service = new ServiceItemServiceImpl();
        ReflectionTestUtils.setField(service, "mapper", mapper);
    }

    @Test
    void addTrimsValidServiceItemBeforeInsert() {
        ServiceItem item = validItem();
        item.setName(" A4黑白打印 ");
        when(mapper.insert(item)).thenReturn(1);

        int rows = service.add(item);

        assertEquals(1, rows);
        assertEquals("A4黑白打印", item.getName());
    }

    @Test
    void addRejectsBlankName() {
        ServiceItem item = validItem();
        item.setName(" ");

        ApiException exception = assertThrows(ApiException.class, () -> service.add(item));

        assertEquals(400, exception.getStatus());
        assertEquals("服务名称不能为空", exception.getMessage());
    }

    @Test
    void addRejectsPriceWithMoreThanTwoDecimals() {
        ServiceItem item = validItem();
        item.setPrice(1.234);

        ApiException exception = assertThrows(ApiException.class, () -> service.add(item));

        assertEquals(400, exception.getStatus());
        assertEquals("服务价格不合法", exception.getMessage());
    }

    @Test
    void addRejectsNonFinitePrice() {
        ServiceItem item = validItem();
        item.setPrice(Double.POSITIVE_INFINITY);

        ApiException exception = assertThrows(ApiException.class, () -> service.add(item));

        assertEquals(400, exception.getStatus());
        assertEquals("服务价格不合法", exception.getMessage());
    }

    @Test
    void updateRequiresId() {
        ServiceItem item = validItem();

        ApiException exception = assertThrows(ApiException.class, () -> service.update(item));

        assertEquals(400, exception.getStatus());
        assertEquals("服务项目ID不能为空", exception.getMessage());
    }

    private ServiceItem validItem() {
        ServiceItem item = new ServiceItem();
        item.setName("A4黑白打印");
        item.setCategory("文档");
        item.setPrice(1.50);
        item.setDescription("标准打印");
        return item;
    }
}
