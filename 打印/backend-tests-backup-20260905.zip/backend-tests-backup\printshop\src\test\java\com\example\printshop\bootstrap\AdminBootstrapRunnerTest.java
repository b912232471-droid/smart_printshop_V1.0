package com.example.printshop.bootstrap;

import com.example.printshop.entity.Admin;
import com.example.printshop.mapper.AdminMapper;
import com.example.printshop.security.FieldCryptoService;
import com.example.printshop.service.impl.AdminServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class AdminBootstrapRunnerTest {
    private AdminMapper adminMapper;
    private BCryptPasswordEncoder passwordEncoder;
    private AdminServiceImpl adminService;

    @BeforeEach
    void setUp() {
        adminMapper = mock(AdminMapper.class);
        passwordEncoder = new BCryptPasswordEncoder();
        adminService = new AdminServiceImpl();
        ReflectionTestUtils.setField(adminService, "adminMapper", adminMapper);
        ReflectionTestUtils.setField(adminService, "passwordEncoder", passwordEncoder);
        ReflectionTestUtils.setField(adminService, "fieldCryptoService", new FieldCryptoService("test-field-crypto-key-with-more-than-32-characters"));
    }

    @Test
    void disabledDoesNothing() {
        AdminBootstrapRunner runner = runner(false, "root_admin", "StrongPass1!", "", "", "");

        runner.run(null);

        verifyNoInteractions(adminMapper);
    }

    @Test
    void existingAdminSkipsBootstrap() {
        Admin existing = new Admin();
        existing.setId(1);
        existing.setUsername("root_admin");
        existing.setEmailHash("existing-email-hash");
        when(adminMapper.selectAll()).thenReturn(List.of(existing));
        AdminBootstrapRunner runner = runner(true, "root_admin", "StrongPass1!", "", "", "");

        runner.run(null);

        verify(adminMapper, never()).insert(any(Admin.class));
    }

    @Test
    void emptyAdminTableCreatesEnabledSuperadmin() {
        AtomicReference<Admin> inserted = new AtomicReference<>();
        when(adminMapper.selectAll()).thenReturn(List.of());
        when(adminMapper.selectByEmailHash(any())).thenReturn(null);
        doAnswer(invocation -> {
            Admin admin = invocation.getArgument(0, Admin.class);
            admin.setId(1);
            inserted.set(admin);
            return 1;
        }).when(adminMapper).insert(any(Admin.class));
        AdminBootstrapRunner runner = runner(true, "ignored", "StrongPass1!", " Root Admin ", "13800000000", "123456@qq.com");

        runner.run(null);

        assertEquals("123456@qq.com", inserted.get().getUsername());
        assertEquals("superadmin", inserted.get().getRole());
        assertEquals(1, inserted.get().getStatus());
        assertTrue(passwordEncoder.matches("StrongPass1!", inserted.get().getPassword()));
        assertEquals("Root Admin", inserted.get().getRealName());
        assertTrue(inserted.get().getPhone().startsWith("ENC:v1:"));
        assertTrue(inserted.get().getEmail().startsWith("ENC:v1:"));
    }

    @Test
    void enabledWithoutEmailFailsStartup() {
        when(adminMapper.selectAll()).thenReturn(List.of());
        AdminBootstrapRunner runner = runner(true, "ignored", "StrongPass1!", "", "", "");

        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> runner.run(null));

        assertTrue(exception.getMessage().contains("PRINTSHOP_BOOTSTRAP_ADMIN_EMAIL"));
        verify(adminMapper, never()).insert(any(Admin.class));
    }

    @Test
    void enabledWithoutPasswordFailsStartup() {
        when(adminMapper.selectAll()).thenReturn(List.of());
        AdminBootstrapRunner runner = runner(true, "ignored", "", "", "", "123456@qq.com");

        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> runner.run(null));

        assertTrue(exception.getMessage().contains("PRINTSHOP_BOOTSTRAP_ADMIN_PASSWORD"));
        verify(adminMapper, never()).insert(any(Admin.class));
    }

    @Test
    void weakBootstrapPasswordFailsThroughAdminService() {
        when(adminMapper.selectAll()).thenReturn(List.of());
        AdminBootstrapRunner runner = runner(true, "ignored", "12345678", "", "", "123456@qq.com");

        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> runner.run(null));

        assertInstanceOf(com.example.printshop.common.ApiException.class, exception.getCause());
        assertTrue(exception.getMessage().contains("密码"));
        verify(adminMapper, never()).insert(any(Admin.class));
    }

    @Test
    void blankOptionalFieldsStayNull() {
        AtomicReference<Admin> inserted = new AtomicReference<>();
        when(adminMapper.selectAll()).thenReturn(List.of());
        when(adminMapper.selectByEmailHash(any())).thenReturn(null);
        doAnswer(invocation -> {
            inserted.set(invocation.getArgument(0, Admin.class));
            return 1;
        }).when(adminMapper).insert(any(Admin.class));
        AdminBootstrapRunner runner = runner(true, "ignored", "StrongPass1!", " ", "", "123456@qq.com");

        runner.run(null);

        assertNull(inserted.get().getRealName());
        assertNull(inserted.get().getPhone());
        assertTrue(inserted.get().getEmail().startsWith("ENC:v1:"));
    }

    private AdminBootstrapRunner runner(boolean enabled,
                                        String username,
                                        String password,
                                        String realName,
                                        String phone,
                                        String email) {
        return new AdminBootstrapRunner(adminMapper, adminService, enabled, username, password, realName, phone, email);
    }
}
