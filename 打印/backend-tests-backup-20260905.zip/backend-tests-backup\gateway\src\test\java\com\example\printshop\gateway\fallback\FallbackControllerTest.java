package com.example.printshop.gateway.fallback;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FallbackControllerTest {
    @Test
    void printServiceFallbackReturnsStableUnavailableResponse() {
        FallbackController controller = new FallbackController();

        ResponseEntity<Map<String, Object>> response = controller.printService().block();

        assertUnavailable(response, "print service unavailable");
    }

    @Test
    void futureServiceFallbacksReturnStableUnavailableResponses() {
        FallbackController controller = new FallbackController();

        assertUnavailable(controller.photoService().block(), "photo service unavailable");
        assertUnavailable(controller.scheduleService().block(), "schedule service unavailable");
        assertUnavailable(controller.chatService().block(), "chat service unavailable");
    }

    private void assertUnavailable(ResponseEntity<Map<String, Object>> response, String message) {
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertEquals(503, response.getBody().get("code"));
        assertEquals(message, response.getBody().get("message"));
    }
}
