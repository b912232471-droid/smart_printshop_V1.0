package com.example.printshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = {
        "printshop.jwt.secret=test-context-secret-with-more-than-32-characters",
        "printshop.crypto.field-key=test-field-crypto-key-with-more-than-32-characters"
})
class PrintshopApplicationTests {

    @Test
    void contextLoads() {
    }

}
